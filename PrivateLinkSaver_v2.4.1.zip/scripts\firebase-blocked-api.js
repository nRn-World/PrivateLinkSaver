// This file is a placeholder to prevent errors when Firebase tries to load external scripts.
// The extension does not use Google Sign-In or Phone Auth, so this script is never actually needed.
console.log('Firebase external API blocked for Manifest V3 compliance');
