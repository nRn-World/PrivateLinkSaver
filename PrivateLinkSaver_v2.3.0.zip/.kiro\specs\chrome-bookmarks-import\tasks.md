# Implementation Plan: Chrome Bookmarks Import

## Overview

Implement the Chrome bookmarks import feature by adding a button to the popup, a new modal with a collapsible tree view, permission handling, and import logic — all within the existing three files (`popup.html`, `styles/popup.css`, `scripts/popup.js`).

## Tasks

- [x] 1. Add "Import from Chrome" button to popup.html and modal markup
  - Add an `<button id="chrome-import-btn">` inside the `.data-actions` div in `popup.html`, alongside the existing Export, Import, and Backup buttons
  - Add the `<div id="chrome-bookmarks-modal" class="modal">` with `.modal-content / .modal-header / .modal-body` structure and a `<div id="chrome-bookmarks-tree">` inside the body
  - _Requirements: 1.1, 2.1_

- [x] 2. Add CSS styles for the bookmark tree nodes
  - [x] 2.1 Write styles for tree node elements in `styles/popup.css`
    - Add styles for `.chrome-tree-node`, `.chrome-tree-folder`, `.chrome-tree-link`, `.chrome-tree-children`, `.chrome-tree-toggle`, `.chrome-node-actions`, and `.chrome-import-btn-sm`
    - Folder nodes should have a folder icon and indent children; link nodes show a favicon
    - _Requirements: 2.3, 2.4_

- [x] 3. Implement Permission Manager and modal open/close in `scripts/popup.js`
  - [x] 3.1 Implement `checkAndRequestBookmarksPermission()`
    - Use `chrome.permissions.contains` then `chrome.permissions.request` if needed
    - Return `true` if granted, show error toast and return `false` if denied
    - _Requirements: 1.2, 1.3, 1.4_
  - [x] 3.2 Implement `openChromeBookmarksModal()` and `closeChromeBookmarksModal()`
    - `openChromeBookmarksModal` calls `checkAndRequestBookmarksPermission()`, then `chrome.bookmarks.getTree()`, then `renderBookmarkTree()`, then shows the modal
    - `closeChromeBookmarksModal` hides the modal and clears `#chrome-bookmarks-tree` to reset state
    - Wire the `chrome-import-btn` click to `openChromeBookmarksModal()` and the modal close button to `closeChromeBookmarksModal()`
    - _Requirements: 1.5, 2.2, 2.8_

- [x] 4. Implement bookmark tree rendering
  - [x] 4.1 Implement `renderBookmarkTree(nodes, container)` and `renderBookmarkNode(node)`
    - `renderBookmarkTree` iterates root nodes and appends rendered elements to the container
    - `renderBookmarkNode` returns a DOM element: folder nodes get a toggle + "Import Folder" button (if `folderHasValidLinks`); link nodes get a favicon + title + "Import Link" button (if valid HTTP/HTTPS URL)
    - Folder expand/collapse toggles the `.chrome-tree-children` element visibility inline
    - _Requirements: 2.2, 2.3, 2.4, 2.5, 2.6, 2.7_
  - [x] 4.2 Implement `folderHasValidLinks(node)` and `collectValidLinks(node)`
    - `folderHasValidLinks` recursively checks if any descendant has a valid HTTP/HTTPS URL
    - `collectValidLinks` recursively walks the tree and returns only link nodes with valid HTTP/HTTPS URLs
    - _Requirements: 2.6, 4.1, 4.2_
  - [ ]* 4.3 Write property test for `renderBookmarkNode` — Property 2: Import button visibility matches URL validity
    - **Property 2: Import button visibility matches URL validity**
    - **Validates: Requirements 2.6, 2.7**
    - Use fast-check to generate arbitrary `ChromeBookmarkNode` values; assert "Import Link" button presence iff URL is valid HTTP/HTTPS, and "Import Folder" button presence iff folder has valid descendant links
  - [ ]* 4.4 Write property test for `collectValidLinks` — Property 5: Folder import collects all valid descendant links
    - **Property 5: Folder import collects all valid descendant links**
    - **Validates: Requirements 4.1, 4.2**
    - Use fast-check to generate arbitrary nested trees; assert result equals exactly the set of all descendant link nodes with valid HTTP/HTTPS URLs

- [x] 5. Implement single link import
  - [x] 5.1 Implement `importSingleLink(node)`
    - Read current bookmarks via `StorageUtils.getBookmarks()`
    - Check for duplicate using `StorageUtils.canonicalUrl()`; if duplicate show toast "link already exists" and return
    - Build bookmark object using `CryptoUtils.generateUUID()`, node title/URL, selected folder from `#folder-select-add`
    - Call `StorageUtils.saveBookmarks([...existing, newBookmark])` and run state refresh sequence
    - Show success toast on completion
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_
  - [ ]* 5.2 Write property test for `importSingleLink` — Property 3: Single link import preserves title and URL
    - **Property 3: Single link import preserves title and URL**
    - **Validates: Requirements 3.1**
    - Use fast-check to generate valid link nodes; assert exactly one new bookmark is added with matching title and canonical URL
  - [ ]* 5.3 Write property test for deduplication in `importSingleLink` — Property 4: No duplicate bookmarks
    - **Property 4: Deduplication — no duplicate bookmarks**
    - **Validates: Requirements 3.4, 5.1, 5.2, 5.3**
    - Use fast-check to generate a node whose canonical URL already exists in the bookmark store; assert bookmark count is unchanged after import

- [x] 6. Implement folder import
  - [x] 6.1 Implement `importFolder(node)`
    - Call `collectValidLinks(node)` to get all valid links; if empty show toast "folder is empty" and return without creating a folder
    - Check existing folders for name match (case-insensitive); create new folder with `CryptoUtils.generateUUID()`, `node.title`, color `#3498db` if none exists, then call `StorageUtils.saveFolders()`
    - Build bookmark objects for all collected links assigned to the resolved folder name
    - Merge with existing bookmarks, deduplicating via `StorageUtils.canonicalUrl()`; track imported and skipped counts
    - Call `StorageUtils.saveBookmarks()` once with the full merged list, then run state refresh sequence
    - Show completion toast with imported and skipped counts
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 5.3, 5.4_
  - [ ]* 6.2 Write property test for folder deduplication — Property 6: No duplicate folders
    - **Property 6: Folder deduplication — no duplicate folders**
    - **Validates: Requirements 4.4**
    - Use fast-check to generate a folder node whose name already exists in the folder store; assert folder count is unchanged after import
  - [ ]* 6.3 Write property test for import count accuracy — Property 7: Import count accuracy
    - **Property 7: Import count accuracy**
    - **Validates: Requirements 4.7, 5.4**
    - Use fast-check to generate arbitrary folder trees; assert imported + skipped equals total valid HTTP/HTTPS links in the tree

- [ ] 7. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 8. Wire state refresh and add i18n keys
  - [x] 8.1 Confirm state refresh sequence runs after every import
    - After each successful import (`importSingleLink`, `importFolder`), verify the sequence: reload `state.bookmarks`, reload `state.folders`, call `updateFolderDropdowns()`, `refreshBookmarkView()`, `await updateStats()`
    - _Requirements: 6.1, 6.2, 6.3, 6.4_
  - [x] 8.2 Add missing translation keys to `_locales/*/messages.json`
    - Add keys: `chrome_import`, `bookmarks_permission_required`, `link_already_exists`, `folder_empty`, `import_complete` (with imported/skipped placeholders) for all five locales (`en`, `sv`, `tr`, `es`, `fr`)
    - _Requirements: 1.4, 3.4, 4.7, 4.8_

- [ ] 9. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for a faster MVP
- Property tests use [fast-check](https://github.com/dubzzz/fast-check) and run in Node/Jest against extracted pure functions
- All Chrome API calls (`chrome.bookmarks`, `chrome.permissions`) are mocked in tests
- Each task references specific requirements for traceability
