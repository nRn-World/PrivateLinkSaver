// PrivateLinkSaver - Popup Script
document.addEventListener('DOMContentLoaded', async function () {
    // Firefox for Android: full-screen popup, touch only, no bookmarks API.
    const isAndroid = /Android/i.test(navigator.userAgent);
    const isTouch = isAndroid || (window.matchMedia && window.matchMedia('(pointer: coarse)').matches);
    if (isAndroid) document.documentElement.classList.add('mobile');
    if (isTouch) document.documentElement.classList.add('touch');

    // Element references
    const elements = {
        loader: document.getElementById('loader'),
        toastContainer: document.getElementById('toast-container'),
        welcomeScreen: document.getElementById('welcome-screen'),
        loginSection: document.getElementById('login-section'),
        registerSection: document.getElementById('register-section'),
        bookmarksSection: document.getElementById('bookmarks-section'),
        bookmarksContainer: document.getElementById('bookmarks-container'),
        emptyState: document.getElementById('empty-state'),
        password: document.getElementById('password'),
        newPassword: document.getElementById('new-password'),
        confirmPassword: document.getElementById('confirm-password'),
        passwordStrength: document.getElementById('password-strength'),
        strengthBar: document.querySelector('.strength-bar'),
        strengthText: document.querySelector('.strength-text'),
        loginBtn: document.getElementById('login-btn'),
        logoutBtn: document.getElementById('logout-btn'),
        showRegisterBtn: document.getElementById('show-register-btn'),
        registerBtn: document.getElementById('register-btn'),
        cancelRegisterBtn: document.getElementById('cancel-register-btn'),
        getStartedBtn: document.getElementById('get-started-btn'),
        addBookmarkBtn: document.getElementById('add-bookmark'),
        showAllBtn: document.getElementById('show-all-btn'),
        hideAllBtn: document.getElementById('hide-all-btn'),
        refreshBtn: document.getElementById('refresh-btn'),
        statsBtn: document.getElementById('stats-btn'),
        settingsBtn: document.getElementById('settings-btn'),
        themeToggle: document.getElementById('theme-toggle'),
        searchBox: document.getElementById('search-box'),
        exportBtn: document.getElementById('export-btn'),
        importBtn: document.getElementById('import-btn'),
        backupBtn: document.getElementById('backup-btn'),
        fileInput: document.getElementById('file-input'),
        folderSelect: document.getElementById('folder-select'),
        folderSelectAdd: document.getElementById('folder-select-add'),
        newFolderBtn: document.getElementById('new-folder-btn'),
        deleteFolderBtn: document.getElementById('delete-folder-btn'),
        folderModal: document.getElementById('folder-modal'),
        backupModal: document.getElementById('backup-modal'),
        statsModal: document.getElementById('stats-modal'),
        folderName: document.getElementById('folder-name'),
        saveFolderBtn: document.getElementById('save-folder-btn'),
        editBookmarkModal: document.getElementById('edit-bookmark-modal'),
        editBookmarkTitle: document.getElementById('edit-bookmark-title'),
        editBookmarkUrl: document.getElementById('edit-bookmark-url'),
        saveBookmarkEditBtn: document.getElementById('save-bookmark-edit-btn'),
        createBackupBtn: document.getElementById('create-backup-btn'),
        autoBackupToggle: document.getElementById('auto-backup-toggle'),
        backupsContainer: document.getElementById('backups-container'),
        sortDateBtn: document.getElementById('sort-date'),
        sortNameBtn: document.getElementById('sort-name'),
        sortVisitsBtn: document.getElementById('sort-visits'),
        tagInput: document.getElementById('tag-input'),
        tagList: document.getElementById('tag-list'),
        smartTagSuggestions: document.getElementById('smart-tag-suggestions'),
        commandPaletteBtn: document.getElementById('command-palette-btn'),
        commandPaletteModal: document.getElementById('command-palette-modal'),
        commandInput: document.getElementById('command-input'),
        commandResults: document.getElementById('command-results'),
        totalBookmarks: document.getElementById('total-bookmarks'),
        totalFolders: document.getElementById('total-folders'),
        totalTags: document.getElementById('total-tags'),
        quickBookmarkCount: document.getElementById('quick-bookmark-count'),
        quickFolderCount: document.getElementById('quick-folder-count'),
        quickTagCount: document.getElementById('quick-tag-count'),
        togglePassword: document.getElementById('toggle-password'),
        cloudSyncStatus: document.getElementById('cloud-sync-status'),
        cloudAccountSection: document.getElementById('cloud-account-section'),
        cloudEmail: document.getElementById('cloud-email'),
        cloudPassword: document.getElementById('cloud-password'),
        toggleCloudPassword: document.getElementById('toggle-cloud-password'),
        cloudLoginBtn: document.getElementById('cloud-login-btn'),
        cloudRegisterBtn: document.getElementById('cloud-register-btn'),
        cloudForgotBtn: document.getElementById('cloud-forgot-btn'),
        backToLoginBtn: document.getElementById('back-to-login-btn'),
        folderColorPicker: document.getElementById('folder-color-picker'),
        folderColorHex: document.getElementById('folder-color-hex')
    };

    // State variables
    let state = {
        currentLang: 'en',
        darkMode: false,
        allBookmarksHidden: false,
        currentFolder: 'all',
        currentTag: null,
        folders: [],
        tags: [],
        bookmarks: [],
        sortBy: 'date',
        selectedFolderColor: '#8e44ad',
        editingBookmarkId: null,
        activeSuggestedTags: [],
        currentTabMeta: null,
        commandIndex: 0,
        activeCommands: [],
        cloudEncryptionKey: null,
        cloudPassword: null,
        cloudSalt: null,
        cloudLoggedIn: false,
        showFavicons: true,
        selectMode: false,
        selectedIds: new Set(),
        visibleIds: [],
        dragIds: []
    };

    function t(key, fallback = '') {
        return translations[state.currentLang]?.[key] || translations.en?.[key] || fallback;
    }

    const TRACKING_PARAM_PREFIXES = ['utm_', 'ga_', 'mc_', 'pk_', 'sc_'];
    const TRACKING_PARAM_EXACT = new Set([
        'fbclid',
        'gclid',
        'dclid',
        'msclkid',
        'yclid',
        '_hsenc',
        '_hsmi',
        'igshid',
        'ref_src',
        'campaign',
        'si'
    ]);

    // Show loader
    function showLoader() {
        elements.loader.classList.add('active');
    }

    // Hide loader
    function hideLoader() {
        elements.loader.classList.remove('active');
    }

    // Show toast notification
    function showToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle'
        };
        
        const icon = document.createElement('i');
        icon.className = `fas fa-${icons[type] || 'info-circle'}`;
        const text = document.createElement('span');
        text.textContent = message;
        toast.appendChild(icon);
        toast.appendChild(text);
        
        elements.toastContainer.appendChild(toast);
        
        setTimeout(() => {
            toast.style.animation = 'slideOutTop 0.3s ease forwards';
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.remove();
                }
            }, 300);
        }, 3000);
    }

    // Apply translation
    function applyTranslation(lang) {
        state.currentLang = lang;
        const langData = translations[lang];
        
        document.querySelectorAll('[data-translate]').forEach(el => {
            const key = el.getAttribute('data-translate');
            if (langData[key]) {
                el.textContent = langData[key];
            }
        });
        
        document.querySelectorAll('[data-translate-placeholder]').forEach(el => {
            const key = el.getAttribute('data-translate-placeholder');
            if (langData[key]) {
                el.setAttribute('placeholder', langData[key]);
            }
        });
        
        // Update active language button
        document.querySelectorAll('.lang-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.lang === lang);
        });

        updateSmartTagSuggestions();
        if (elements.commandPaletteModal.classList.contains('active')) {
            renderCommandResults(elements.commandInput.value);
        }
    }

    // Toggle dark/light theme
    function toggleTheme() {
        state.darkMode = !state.darkMode;
        document.body.setAttribute('data-theme', state.darkMode ? 'dark' : 'light');
        setFaIcon(elements.themeToggle, state.darkMode ? 'fas fa-sun' : 'fas fa-moon');
        StorageUtils.savePreferences({ darkMode: state.darkMode });
    }

    function applyUiStyle(style) {
        const isPastel = style === 'pastel';
        const clayLink = document.getElementById('clay-theme-css');
        if (clayLink) clayLink.disabled = !isPastel;
        document.body.setAttribute('data-ui-style', isPastel ? 'pastel' : 'classic');
    }

    // Initialize theme
    async function initTheme() {
        const prefs = await StorageUtils.getPreferences();
        state.darkMode = prefs.darkMode;
        state.currentLang = prefs.language;
        state.showFavicons = prefs.showFavicons;

        applyUiStyle(prefs.uiStyle || 'classic');

        const banner = document.getElementById('new-design-banner');
        const tryBtn = document.getElementById('try-new-design-btn');
        const closeBtn = document.getElementById('dismiss-design-banner');
        if (banner && prefs.showStyleBanner && prefs.uiStyle !== 'pastel') {
            banner.hidden = false;
        }
        if (tryBtn && !tryBtn.dataset.bound) {
            tryBtn.dataset.bound = '1';
            tryBtn.addEventListener('click', async () => {
                applyUiStyle('pastel');
                if (banner) banner.hidden = true;
                await StorageUtils.savePreferences({ uiStyle: 'pastel', showStyleBanner: false });
            });
        }
        if (closeBtn && !closeBtn.dataset.bound) {
            closeBtn.dataset.bound = '1';
            closeBtn.addEventListener('click', async () => {
                if (banner) banner.hidden = true;
                await StorageUtils.savePreferences({ showStyleBanner: false });
            });
        }

        if (state.darkMode) {
            document.body.setAttribute('data-theme', 'dark');
            setFaIcon(elements.themeToggle, 'fas fa-sun');
        }
        
        // Set auto-backup toggle
        elements.autoBackupToggle.checked = prefs.autoBackup;
    }

    // Load folders
    async function loadFolders() {
        const storedFolders = await StorageUtils.getFolders();
        
        if (storedFolders.length === 0) {
            // Create default folders
            const defaultFolderData = defaultFolders.map(key => ({
                id: CryptoUtils.generateUUID(),
                name: translations[state.currentLang][key],
                color: folderColors[key] || '#0ea5e9',
                isDefault: true,
                key: key
            }));
            
            await StorageUtils.saveFolders(defaultFolderData);
            state.folders = defaultFolderData;
        } else {
            // Translate default folder names
            const renames = new Map();
            const translated = storedFolders.map(folder => {
                if (folder.isDefault && folder.key) {
                    const name = translations[state.currentLang][folder.key] || folder.name;
                    if (name !== folder.name) renames.set(folder.name, name);
                    return { ...folder, name };
                }
                return folder;
            });

            if (renames.size === 0) {
                state.folders = storedFolders;
            } else {
                // Bookmarks reference folders by name, so move them along with the rename.
                // If they can not be read/written (locked vault), keep the old names.
                try {
                    const bookmarks = await StorageUtils.getBookmarks();
                    const moved = bookmarks.map(b => renames.has(b.folder) ? { ...b, folder: renames.get(b.folder) } : b);
                    await StorageUtils.saveBookmarks(moved);
                    await StorageUtils.saveFolders(translated);
                    state.folders = translated;
                } catch (_error) {
                    state.folders = storedFolders;
                }
            }
        }
        
        updateFolderDropdowns();
    }

    // Load tags
    async function loadTags() {
        state.tags = await StorageUtils.getTags();
        updateTagList();
    }

    async function refreshCurrentTabMeta() {
        return new Promise((resolve) => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                const tab = tabs && tabs[0] ? tabs[0] : null;
                if (!tab || !isSafeHttpUrl(tab.url)) {
                    state.currentTabMeta = null;
                    state.activeSuggestedTags = [];
                    updateSmartTagSuggestions();
                    resolve(null);
                    return;
                }

                state.currentTabMeta = {
                    title: String(tab.title || tab.url || 'Untitled').trim(),
                    url: normalizeHttpUrl(tab.url),
                    favIconUrl: tab.favIconUrl || null
                };
                state.activeSuggestedTags = inferTagsFromMeta(state.currentTabMeta.url, state.currentTabMeta.title);
                updateSmartTagSuggestions();
                resolve(state.currentTabMeta);
            });
        });
    }

    function updateSmartTagSuggestions() {
        if (!elements.smartTagSuggestions) return;

        clearChildren(elements.smartTagSuggestions);
        if (!state.activeSuggestedTags.length) return;

        const enteredTags = elements.tagInput.value
            .split(',')
            .map((tag) => tag.trim().toLowerCase())
            .filter(Boolean);

        state.activeSuggestedTags.forEach((tag) => {
            const chip = document.createElement('button');
            chip.type = 'button';
            chip.className = 'smart-tag-chip';
            chip.textContent = `+${tag}`;
            if (enteredTags.includes(tag.toLowerCase())) {
                chip.classList.add('active');
            }

            chip.addEventListener('click', () => {
                const existing = elements.tagInput.value
                    .split(',')
                    .map((entry) => entry.trim())
                    .filter(Boolean);
                const merged = mergeTags(existing, [tag]);
                elements.tagInput.value = merged.join(', ');
                updateSmartTagSuggestions();
            });

            elements.smartTagSuggestions.appendChild(chip);
        });
    }

    // Update folder dropdowns
    function updateFolderDropdowns() {
        clearChildren(elements.folderSelect);
        clearChildren(elements.folderSelectAdd);
        
        // All folders option
        const allOption = document.createElement('option');
        allOption.value = 'all';
        allOption.textContent = translations[state.currentLang]['all_folders'];
        elements.folderSelect.appendChild(allOption);
        
        // Add each folder
        state.folders.forEach(folder => {
            const option = document.createElement('option');
            option.value = folder.name;
            option.textContent = folder.name;
            option.style.color = folder.color;
            elements.folderSelect.appendChild(option.cloneNode(true));
            elements.folderSelectAdd.appendChild(option);
        });
        
        // Initialize color
        const updateSelectColor = (select) => {
            const selectedOption = select.options[select.selectedIndex];
            if (selectedOption && selectedOption.style.color) {
                select.style.color = selectedOption.style.color;
            } else {
                select.style.color = 'inherit';
            }
        };

        updateSelectColor(elements.folderSelect);
        updateSelectColor(elements.folderSelectAdd);
        
        fillBulkMove();

        // Update stats
        if (elements.totalFolders) elements.totalFolders.textContent = state.folders.length;
        if (elements.quickFolderCount) elements.quickFolderCount.textContent = state.folders.length;
    }

    // Update tag list
    function updateTagList() {
        if (elements.tagList) {
            clearChildren(elements.tagList);
            
            state.tags.forEach(tag => {
                const tagEl = document.createElement('span');
                tagEl.className = 'tag-item';
                tagEl.textContent = tag.name;
                tagEl.style.backgroundColor = `${tag.color}20`;
                tagEl.style.color = tag.color;
                tagEl.style.borderColor = tag.color;
                
                if (state.currentTag === tag.name) {
                    tagEl.classList.add('active');
                }
                
                tagEl.addEventListener('click', () => {
                    state.currentTag = state.currentTag === tag.name ? null : tag.name;
                    updateTagList();
                    filterBookmarks();
                });
                
                elements.tagList.appendChild(tagEl);
            });
        }
        
        if (elements.totalTags) elements.totalTags.textContent = state.tags.length;
        if (elements.quickTagCount) elements.quickTagCount.textContent = state.tags.length;
    }

    // Update stats display
    async function updateStats() {
        const stats = await StorageUtils.getStatistics();
        
        if (elements.totalBookmarks) elements.totalBookmarks.textContent = stats.totalBookmarks;
        if (elements.totalFolders) elements.totalFolders.textContent = stats.totalFolders;
        if (elements.totalTags) elements.totalTags.textContent = stats.totalTags;
        if (elements.quickBookmarkCount) elements.quickBookmarkCount.textContent = stats.totalBookmarks;
        if (elements.quickFolderCount) elements.quickFolderCount.textContent = stats.totalFolders;
        if (elements.quickTagCount) elements.quickTagCount.textContent = stats.totalTags;
        
        // Update stats modal
        document.getElementById('stat-bookmarks').textContent = stats.totalBookmarks;
        document.getElementById('stat-folders').textContent = stats.totalFolders;
        document.getElementById('stat-tags').textContent = stats.totalTags;
        document.getElementById('stat-visits').textContent = stats.totalVisits;
        
        // Update top domains
        const domainList = document.getElementById('domain-list');
        clearChildren(domainList);
        
        stats.topDomains.forEach(({ domain, count }) => {
            const item = document.createElement('div');
            item.className = 'domain-item';

            const domainName = document.createElement('span');
            domainName.className = 'domain-name';

            const icon = document.createElement('img');
            if (state.showFavicons) icon.src = `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=16`;
            else icon.hidden = true;
            icon.alt = '';

            const domainText = document.createElement('span');
            domainText.textContent = domain;

            const domainCount = document.createElement('span');
            domainCount.className = 'domain-count';
            domainCount.textContent = String(count);

            domainName.appendChild(icon);
            domainName.appendChild(domainText);
            item.appendChild(domainName);
            item.appendChild(domainCount);
            domainList.appendChild(item);
        });
    }

    // Show welcome screen
    async function showWelcomeScreen() {
        elements.welcomeScreen.style.display = 'block';
        elements.loginSection.style.display = 'none';
        elements.registerSection.style.display = 'none';
        elements.bookmarksSection.style.display = 'none';

        const pinHint = document.getElementById('pin-hint');
        if (pinHint) {
            const { showPinHint } = await chrome.storage.local.get('showPinHint');
            pinHint.hidden = showPinHint !== true;
        }
        
        await updateStats();
    }

    // Show bookmarks
    async function showBookmarks() {
        state.bookmarks = await StorageUtils.getBookmarks();
        refreshBookmarkView();
        
        elements.loginSection.style.display = 'none';
        elements.registerSection.style.display = 'none';
        elements.welcomeScreen.style.display = 'none';
        elements.bookmarksSection.style.display = 'block';
        
        await updateStats();
        await refreshCurrentTabMeta();
    await updateCloudUI();
    }

    // Display bookmarks
    function displayBookmarks(bookmarks, options = {}) {
        clearChildren(elements.bookmarksContainer);

        const list = options.preSorted ? bookmarks : sortBookmarks(bookmarks);
        state.visibleIds = list.map((b) => b.id);
        updateBulkBar();

        if (list.length === 0) {
            elements.bookmarksContainer.appendChild(elements.emptyState);
            const hasFilters = Boolean(elements.searchBox.value.trim()) || elements.folderSelect.value !== 'all' || Boolean(state.currentTag);
            const titleNode = elements.emptyState.querySelector('p');
            const subtitleNode = elements.emptyState.querySelector('span');
            if (hasFilters) {
                if (titleNode) titleNode.textContent = t('no_results_title', 'No matches found');
                if (subtitleNode) subtitleNode.textContent = t('no_results_subtitle', 'Try another keyword or filter');
            } else {
                if (titleNode) titleNode.textContent = t('no_bookmarks_yet', 'No bookmarks yet');
                if (subtitleNode) subtitleNode.textContent = t('start_saving', 'Start saving your favorite pages!');
            }
            elements.emptyState.style.display = 'flex';
            return;
        }

        list.forEach((bookmark) => {
            const item = createBookmarkElement(bookmark);
            elements.bookmarksContainer.appendChild(item);
        });

        // Never show count on badge - keep it clean
        try { chrome.action.setBadgeText({ text: '' }); } catch (_error) { /* unsupported platform */ }
    }

    // Event delegation for bookmark actions
    elements.bookmarksContainer.addEventListener('click', async (e) => {
        const actionBtn = e.target.closest('.bookmark-action-btn');
        if (!actionBtn) return;

        const action = actionBtn.dataset.action;
        const bookmarkId = actionBtn.dataset.id;
        const bookmark = state.bookmarks.find(b => b.id === bookmarkId);
        if (!bookmark) return;

        switch (action) {
            case 'edit':
                openEditBookmarkModal(bookmark);
                break;
            case 'copy':
                navigator.clipboard.writeText(bookmark.url);
                showToast(t('link_copied'));
                break;
            case 'delete':
                await deleteBookmark(bookmarkId);
                break;
        }
    });

    // Create bookmark element
    function createBookmarkElement(bookmark) {
        const el = document.createElement('div');
        el.className = 'bookmark-item';
        el.dataset.bookmarkId = bookmark.id;
        el.dataset.folder = bookmark.folder;
        el.dataset.tags = JSON.stringify(bookmark.tags || []);

        // Drag (this one, or the whole selection) onto a folder chip to move.
        el.draggable = !isTouch; // drag & drop is mouse-only; touch uses Select mode
        el.addEventListener('dragstart', (e) => {
            state.dragIds = state.selectMode && state.selectedIds.has(bookmark.id) ? [...state.selectedIds] : [bookmark.id];
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/plain', bookmark.url);
            el.classList.add('dragging');
            setTimeout(showFolderDropBar, 0);
        });
        el.addEventListener('dragend', () => {
            el.classList.remove('dragging');
            hideFolderDropBar();
        });
        if (state.selectedIds.has(bookmark.id)) el.classList.add('selected');
        
        if (state.allBookmarksHidden) {
            el.classList.add('hidden');
        }
        
        const safeUrl = normalizeHttpUrl(bookmark.url);
        const safeHref = safeUrl || '#';
        const safeUrlText = safeUrl || String(bookmark.url || '');
        const visitCount = Number(bookmark.visitCount) || 0;

        const header = document.createElement('div');
        header.className = 'bookmark-header';

        // Site icons as before; the "Show site icons" setting off = local letter icons, no requests.
        let favicon;
        if (state.showFavicons) {
            favicon = document.createElement('img');
            favicon.src = normalizeHttpUrl(bookmark.favicon) || getFavicon(bookmark.url);
            favicon.alt = '';
        } else {
            favicon = document.createElement('span');
            favicon.className = 'letter-icon';
            favicon.textContent = (String(bookmark.title || safeUrlText).match(/[\p{L}\p{N}]/u) || ['#'])[0].toUpperCase();
        }
        favicon.classList.add('bookmark-favicon');

        const title = document.createElement('span');
        title.className = 'bookmark-title';
        title.textContent = bookmark.title || '';

        const actions = document.createElement('div');
        actions.className = 'bookmark-actions';

        const editBtn = document.createElement('button');
        editBtn.className = 'bookmark-action-btn edit';
        editBtn.dataset.action = 'edit';
        editBtn.dataset.id = bookmark.id;
        editBtn.title = translations[state.currentLang]['edit'];
        editBtn.appendChild(svgUse('#icon-edit', 'icon'));

        const copyBtn = document.createElement('button');
        copyBtn.className = 'bookmark-action-btn copy';
        copyBtn.dataset.action = 'copy';
        copyBtn.dataset.id = bookmark.id;
        copyBtn.title = t('copy');
        copyBtn.appendChild(svgUse('#icon-copy', 'icon'));

        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'bookmark-action-btn delete';
        deleteBtn.dataset.action = 'delete';
        deleteBtn.dataset.id = bookmark.id;
        deleteBtn.title = translations[state.currentLang]['delete'];
        deleteBtn.appendChild(svgUse('#icon-trash', 'icon'));

        actions.appendChild(editBtn);
        actions.appendChild(copyBtn);
        actions.appendChild(deleteBtn);
        if (state.selectMode) {
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.className = 'bookmark-select';
            checkbox.checked = state.selectedIds.has(bookmark.id);
            checkbox.addEventListener('change', () => {
                if (checkbox.checked) state.selectedIds.add(bookmark.id);
                else state.selectedIds.delete(bookmark.id);
                el.classList.toggle('selected', checkbox.checked);
                updateBulkBar();
            });
            header.appendChild(checkbox);
        }
        header.appendChild(favicon);
        header.appendChild(title);
        header.appendChild(actions);

        const urlWrap = document.createElement('div');
        urlWrap.className = 'bookmark-url';
        const link = document.createElement('a');
        link.href = safeHref;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.textContent = safeUrlText;
        urlWrap.appendChild(link);

        const meta = document.createElement('div');
        meta.className = 'bookmark-meta';
        const dateSpan = document.createElement('span');
        dateSpan.className = 'bookmark-date';
        dateSpan.textContent = bookmark.date || '';
        meta.appendChild(dateSpan);

        if (visitCount > 0) {
            const visits = document.createElement('span');
            const eye = document.createElement('i');
            eye.className = 'fas fa-eye';
            visits.appendChild(eye);
            visits.appendChild(document.createTextNode(' ' + visitCount));
            meta.appendChild(visits);
        }

        const folderSelect = document.createElement('select');
        folderSelect.className = 'bookmark-folder-select';
        const folderColor = state.folders.find(f => f.name === bookmark.folder)?.color || 'inherit';
        folderSelect.style.color = folderColor;
        state.folders.forEach((f) => {
            const opt = document.createElement('option');
            opt.value = f.name;
            opt.textContent = f.name;
            opt.style.color = f.color;
            if (f.name === bookmark.folder) opt.selected = true;
            folderSelect.appendChild(opt);
        });
        meta.appendChild(folderSelect);

        el.appendChild(header);
        el.appendChild(urlWrap);
        el.appendChild(meta);

        if ((bookmark.tags || []).length > 0) {
            const tagsWrap = document.createElement('div');
            tagsWrap.className = 'bookmark-tags';
            bookmark.tags.forEach((tag) => {
                const tagEl = document.createElement('span');
                tagEl.className = 'bookmark-tag';
                tagEl.textContent = tag;
                tagsWrap.appendChild(tagEl);
            });
            el.appendChild(tagsWrap);
        }
        
        // Event listeners - using event delegation
        // Track visit
        link.addEventListener('click', async () => {
            await trackVisit(bookmark.id);
        });
        
        folderSelect.addEventListener('change', async (e) => {
            const newFolder = e.target.value;
            const folderData = state.folders.find(f => f.name === newFolder);
            if (folderData) {
                e.target.style.color = folderData.color;
            } else {
                e.target.style.color = 'inherit';
            }
            await updateBookmarkFolder(bookmark.id, newFolder);
        });
        
        return el;
    }

    // Sort bookmarks
    function sortBookmarks(bookmarks) {
        const sorted = [...bookmarks];
        
        switch (state.sortBy) {
            case 'date':
                sorted.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
                break;
            case 'name':
                sorted.sort((a, b) => a.title.localeCompare(b.title));
                break;
            case 'visits':
                sorted.sort((a, b) => (b.visitCount || 0) - (a.visitCount || 0));
                break;
        }
        
        return sorted;
    }

    // Filter bookmarks
    function filterBookmarks() {
        const searchTerm = elements.searchBox.value.toLowerCase();
        const selectedFolder = elements.folderSelect.value;

        const filtered = state.bookmarks
            .map((bookmark) => {
                const matchesFolder = selectedFolder === 'all' || bookmark.folder === selectedFolder;
                const matchesTag = !state.currentTag || (bookmark.tags || []).includes(state.currentTag);
                const score = getSearchScore(bookmark, searchTerm);
                const matchesSearch = !searchTerm || score > 0;

                return {
                    bookmark,
                    score,
                    matches: matchesFolder && matchesTag && matchesSearch
                };
            })
            .filter((entry) => entry.matches);

        if (searchTerm) {
            filtered.sort((a, b) => {
                if (b.score !== a.score) return b.score - a.score;
                return (b.bookmark.timestamp || 0) - (a.bookmark.timestamp || 0);
            });
            displayBookmarks(filtered.map((entry) => entry.bookmark), { preSorted: true });
        } else {
            displayBookmarks(filtered.map((entry) => entry.bookmark));
        }

        if (state.allBookmarksHidden) {
            elements.bookmarksContainer.querySelectorAll('.bookmark-item').forEach((item) => {
                item.classList.add('hidden');
            });
        }
    }

    function refreshBookmarkView() {
        filterBookmarks();
    }

    function getSearchScore(bookmark, searchTerm) {
        if (!searchTerm) return 1;

        const title = String(bookmark.title || '').toLowerCase();
        const url = String(bookmark.url || '').toLowerCase();
        const tags = (bookmark.tags || []).join(' ').toLowerCase();
        const folder = String(bookmark.folder || '').toLowerCase();

        let score = 0;
        if (title.startsWith(searchTerm)) score += 150;
        if (title.includes(searchTerm)) score += 100;
        if (url.includes(searchTerm)) score += 60;
        if (tags.includes(searchTerm)) score += 75;
        if (folder.includes(searchTerm)) score += 30;
        if ((bookmark.tags || []).some((tag) => String(tag).toLowerCase() === searchTerm)) score += 90;

        return score;
    }

    // Delete bookmark
    async function deleteBookmark(bookmarkId) {
        const index = getBookmarkIndexById(bookmarkId);
        if (index === -1) return;

        state.bookmarks.splice(index, 1);
        await StorageUtils.saveBookmarks(state.bookmarks);
        refreshBookmarkView();
        showToast(translations[state.currentLang]['delete'] + '!');
        await updateStats();
    }

    // Update bookmark folder
    async function updateBookmarkFolder(bookmarkId, newFolder) {
        const index = getBookmarkIndexById(bookmarkId);
        if (index === -1) return;

        state.bookmarks[index].folder = newFolder;
        await StorageUtils.saveBookmarks(state.bookmarks);
        refreshBookmarkView();
    }

    // Track visit
    async function trackVisit(bookmarkId) {
        const index = getBookmarkIndexById(bookmarkId);
        if (index === -1) return;

        state.bookmarks[index].visitCount = (state.bookmarks[index].visitCount || 0) + 1;
        state.bookmarks[index].lastVisited = Date.now();
        // The popup closes when the new tab opens, so the background script does the save.
        Promise.resolve(chrome.runtime.sendMessage({ action: 'trackVisit', id: bookmarkId })).catch(() => {});
    }

    function getBookmarkIndexById(bookmarkId) {
        return state.bookmarks.findIndex((bookmark) => bookmark.id === bookmarkId);
    }

    // Get favicon URL
    function getFavicon(url) {
        try {
            const urlObj = new URL(url);
            let domain = urlObj.hostname;

            // Add robust validation for the domain name
            if (domain && domain.includes('.') && domain !== 'localhost' && !/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(domain)) {
                return `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
            } else {
                // Fallback for invalid or malformed domains
                return 'https://www.google.com/s2/favicons?domain=example.com&sz=64';
            }
        } catch {
            // Fallback for completely unparseable URLs
            return 'https://www.google.com/s2/favicons?domain=example.com&sz=64';
        }
    }

    function normalizeHttpUrl(url) {
        try {
            const parsed = new URL(String(url || '').trim());
            if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
                return null;
            }

            Array.from(parsed.searchParams.keys()).forEach((paramName) => {
                const key = paramName.toLowerCase();
                if (TRACKING_PARAM_EXACT.has(key) || TRACKING_PARAM_PREFIXES.some((prefix) => key.startsWith(prefix))) {
                    parsed.searchParams.delete(paramName);
                }
            });

            // Keep "#/route" and "#!route" (hash-routed apps); drop plain anchors.
            if (!/^#[\/!]/.test(parsed.hash)) parsed.hash = '';
            parsed.hostname = parsed.hostname.toLowerCase();

            if (parsed.pathname !== '/' && parsed.pathname.endsWith('/')) {
                parsed.pathname = parsed.pathname.replace(/\/+$/, '');
            }

            if ((parsed.protocol === 'https:' && parsed.port === '443') || (parsed.protocol === 'http:' && parsed.port === '80')) {
                parsed.port = '';
            }

            return parsed.href;
        } catch {
            return null;
        }
    }

    function isSafeHttpUrl(url) {
        return normalizeHttpUrl(url) !== null;
    }

    function canonicalUrl(url) {
        return normalizeHttpUrl(url);
    }

    function getDomainTag(url) {
        try {
            const hostname = new URL(url).hostname.replace(/^www\./, '').toLowerCase();
            if (!hostname) return null;
            const domainRoot = hostname.split('.')[0];
            return domainRoot && domainRoot.length > 2 ? domainRoot : null;
        } catch {
            return null;
        }
    }

    function inferTagsFromMeta(url, title) {
        const suggested = [];
        const domainTag = getDomainTag(url);
        if (domainTag) {
            suggested.push(domainTag);
        }

        const stopWords = new Set([
            'the', 'and', 'for', 'with', 'this', 'that', 'from', 'your', 'you', 'are', 'was', 'how',
            'what', 'when', 'where', 'will', 'can', 'about', 'into', 'out', 'why', 'new', 'best',
            'guide', 'tips', 'www', 'com', 'org', 'net', 'se', 'en', 'sv', 'tr', 'fr', 'es'
        ]);

        String(title || '')
            .toLowerCase()
            .replace(/[^a-z0-9\s-]/g, ' ')
            .split(/\s+/)
            .filter((word) => word.length >= 4 && !stopWords.has(word))
            .slice(0, 8)
            .forEach((word) => {
                if (!suggested.includes(word)) {
                    suggested.push(word);
                }
            });

        return suggested.slice(0, 4);
    }

    function colorFromTagName(name) {
        let hash = 0;
        for (let i = 0; i < name.length; i += 1) {
            hash = (hash << 5) - hash + name.charCodeAt(i);
            hash |= 0;
        }
        const hue = Math.abs(hash) % 360;
        return `hsl(${hue}, 68%, 48%)`;
    }

    function mergeTags(...tagLists) {
        const seen = new Set();
        const merged = [];
        tagLists.flat().forEach((tag) => {
            const value = String(tag || '').trim();
            if (!value) return;
            const key = value.toLowerCase();
            if (seen.has(key)) return;
            seen.add(key);
            merged.push(value);
        });
        return merged.slice(0, 10);
    }

    // Escape HTML (read-only .innerHTML â€” no assignment)
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = String(text ?? '');
        return div.innerHTML;
    }

    function clearChildren(el) {
        if (!el) return;
        while (el.firstChild) el.removeChild(el.firstChild);
    }

    function setFaIcon(el, className) {
        clearChildren(el);
        const i = document.createElement('i');
        i.className = className;
        el.appendChild(i);
    }

    function svgUse(href, className) {
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        if (className) svg.setAttribute('class', className);
        svg.setAttribute('viewBox', '0 0 24 24');
        const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
        use.setAttribute('href', href);
        svg.appendChild(use);
        return svg;
    }

    // Check password strength
    function checkPasswordStrength(password) {
        const result = CryptoUtils.checkPasswordStrength(password);
        
        elements.passwordStrength.classList.add('active');
        elements.strengthBar.className = 'strength-bar ' + result.strength;
        
        const strengthTexts = {
            weak: t('password_strength_weak', 'Weak password'),
            medium: t('password_strength_medium', 'Medium password'),
            strong: t('password_strength_strong', 'Strong password')
        };
        
        elements.strengthText.textContent = strengthTexts[result.strength];
    }

    // Modal functions
    function openModal(modal) {
        modal.classList.add('active');
    }

    function closeModal(modal) {
        modal.classList.remove('active');
    }

    function getCommandPaletteActions() {
        return [
            {
                id: 'save-page',
                label: t('cmd_save_page', 'Save current page'),
                icon: 'fa-plus-circle',
                shortcut: 'Ctrl+D',
                run: () => elements.addBookmarkBtn.click()
            },
            {
                id: 'focus-search',
                label: t('cmd_focus_search', 'Focus search'),
                icon: 'fa-search',
                shortcut: 'Ctrl+K',
                run: () => elements.searchBox.focus()
            },
            {
                id: 'new-folder',
                label: t('cmd_new_folder', 'Create new folder'),
                icon: 'fa-folder-plus',
                shortcut: 'Ctrl+N',
                run: () => elements.newFolderBtn.click()
            },
            {
                id: 'stats',
                label: t('statistics', 'Statistics'),
                icon: 'fa-chart-bar',
                shortcut: '-',
                run: () => elements.statsBtn.click()
            },
            {
                id: 'backup',
                label: t('backup_restore', 'Backup & Restore'),
                icon: 'fa-hdd',
                shortcut: '-',
                run: () => elements.backupBtn.click()
            },
            {
                id: 'export',
                label: t('export', 'Export'),
                icon: 'fa-file-export',
                shortcut: '-',
                run: () => elements.exportBtn.click()
            },
            {
                id: 'import',
                label: t('import', 'Import'),
                icon: 'fa-file-import',
                shortcut: '-',
                run: () => elements.importBtn.click()
            },
            {
                id: 'theme',
                label: t('cmd_toggle_theme', 'Toggle theme'),
                icon: 'fa-circle-half-stroke',
                shortcut: '-',
                run: () => elements.themeToggle.click()
            },
            {
                id: 'settings',
                label: t('settings_title', 'Settings'),
                icon: 'fa-cog',
                shortcut: '-',
                run: () => elements.settingsBtn.click()
            },
            {
                id: 'logout',
                label: t('logout', 'Logout'),
                icon: 'fa-right-from-bracket',
                shortcut: '-',
                run: () => elements.logoutBtn.click()
            }
        ];
    }

    function renderCommandResults(filterText = '') {
        const text = String(filterText || '').toLowerCase().trim();
        const allCommands = getCommandPaletteActions();
        const filtered = allCommands.filter((command) => {
            return !text || command.label.toLowerCase().includes(text) || command.id.includes(text);
        });

        state.activeCommands = filtered;
        state.commandIndex = Math.max(0, Math.min(state.commandIndex, Math.max(filtered.length - 1, 0)));
        clearChildren(elements.commandResults);

        filtered.forEach((command, index) => {
            const item = document.createElement('button');
            item.type = 'button';
            item.className = `command-item ${index === state.commandIndex ? 'active' : ''}`;

            const main = document.createElement('span');
            main.className = 'command-item-main';

            const icon = document.createElement('i');
            icon.className = `fas ${command.icon}`;
            const label = document.createElement('span');
            label.textContent = command.label;
            main.appendChild(icon);
            main.appendChild(label);

            const shortcut = document.createElement('span');
            shortcut.className = 'command-shortcut';
            shortcut.textContent = command.shortcut;

            item.appendChild(main);
            item.appendChild(shortcut);
            item.addEventListener('click', () => executeCommand(command));
            elements.commandResults.appendChild(item);
        });
    }

    function executeCommand(command) {
        if (!command) return;
        closeModal(elements.commandPaletteModal);
        command.run();
    }

    function openCommandPalette() {
        state.commandIndex = 0;
        openModal(elements.commandPaletteModal);
        renderCommandResults('');
        setTimeout(() => {
            elements.commandInput.value = '';
            elements.commandInput.focus();
        }, 40);
    }

    function moveCommandSelection(step) {
        if (!state.activeCommands.length) return;
        const lastIndex = state.activeCommands.length - 1;
        state.commandIndex = Math.max(0, Math.min(lastIndex, state.commandIndex + step));
        renderCommandResults(elements.commandInput.value);
    }

    // Load backups
    async function loadBackups() {
        const backups = await StorageUtils.getBackups();
        clearChildren(elements.backupsContainer);
        
        if (backups.length === 0) {
            const emptyText = document.createElement('p');
            emptyText.style.textAlign = 'center';
            emptyText.style.color = 'var(--text-muted)';
            emptyText.textContent = t('no_backups_yet', 'No backups yet');
            elements.backupsContainer.appendChild(emptyText);
            return;
        }
        
        backups.reverse().forEach(backup => {
            const item = document.createElement('div');
            item.className = 'backup-item';

            const backupDate = document.createElement('span');
            backupDate.className = 'backup-date';
            backupDate.textContent = new Date(backup.date).toLocaleString();

            const backupActions = document.createElement('div');
            backupActions.className = 'backup-actions';

            const restoreBtn = document.createElement('button');
            restoreBtn.className = 'backup-btn restore';
            restoreBtn.textContent = t('restore', 'Restore');

            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'backup-btn delete';
            deleteBtn.textContent = t('delete', 'Delete');

            backupActions.appendChild(restoreBtn);
            backupActions.appendChild(deleteBtn);
            item.appendChild(backupDate);
            item.appendChild(backupActions);
            
            restoreBtn.addEventListener('click', async () => {
                if (confirm(t('restore_backup_confirm', 'Are you sure you want to restore this backup? Current data will be replaced.'))) {
                    showLoader();
                    await StorageUtils.restoreFromBackup(backup.id);
                    state.bookmarks = await StorageUtils.getBookmarks();
                    refreshBookmarkView();
                    hideLoader();
                    showToast(t('backup_restored', 'Backup restored!'));
                    closeModal(elements.backupModal);
                }
            });
            
            deleteBtn.addEventListener('click', async () => {
                await StorageUtils.deleteBackup(backup.id);
                loadBackups();
            });
            
            elements.backupsContainer.appendChild(item);
        });
    }

    // Event Listeners
    
    // Language buttons
    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const lang = this.dataset.lang;
            applyTranslation(lang);
            StorageUtils.savePreferences({ language: lang });
            loadFolders().then(() => refreshBookmarkView());
        });
    });

    // Theme toggle
    elements.themeToggle.addEventListener('click', toggleTheme);

    elements.commandPaletteBtn.addEventListener('click', openCommandPalette);
    elements.commandInput.addEventListener('input', (event) => {
        state.commandIndex = 0;
        renderCommandResults(event.target.value);
    });
    elements.commandInput.addEventListener('keydown', (event) => {
        if (event.key === 'ArrowDown') {
            event.preventDefault();
            moveCommandSelection(1);
        } else if (event.key === 'ArrowUp') {
            event.preventDefault();
            moveCommandSelection(-1);
        } else if (event.key === 'Enter') {
            event.preventDefault();
            executeCommand(state.activeCommands[state.commandIndex]);
        }
    });

    // Get started
    elements.getStartedBtn.addEventListener('click', async () => {
        elements.welcomeScreen.style.display = 'none';
        await chrome.storage.local.set({ showPinHint: false, firstTime: false });
        const { hash } = await StorageUtils.getPasswordData();
        if (hash) {
            showBookmarks();
        } else {
            elements.registerSection.style.display = 'block';
        }
    });

    // Show register
    elements.showRegisterBtn.addEventListener('click', () => {
        elements.loginSection.style.display = 'none';
        elements.welcomeScreen.style.display = 'none';
        elements.registerSection.style.display = 'block';
    });

    // Cancel register
    elements.cancelRegisterBtn.addEventListener('click', () => {
        elements.registerSection.style.display = 'none';
        elements.loginSection.style.display = 'block';
        elements.newPassword.value = '';
        elements.confirmPassword.value = '';
        elements.passwordStrength.classList.remove('active');
    });

    // Password strength check
    elements.newPassword.addEventListener('input', (e) => {
        checkPasswordStrength(e.target.value);
    });

    // Toggle password visibility
    elements.togglePassword.addEventListener('click', () => {
        const type = elements.password.type === 'password' ? 'text' : 'password';
        elements.password.type = type;
        setFaIcon(elements.togglePassword, type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash');
    });

    // Register
    elements.registerBtn.addEventListener('click', async () => {
        const password = elements.newPassword.value;
        const confirmPassword = elements.confirmPassword.value;
        
        if (password !== confirmPassword) {
            showToast(translations[state.currentLang]['password_mismatch'], 'error');
            return;
        }
        
        if (password.length < 6) {
            showToast(translations[state.currentLang]['password_length'], 'error');
            return;
        }
        
        showLoader();
        
        const { hash, salt } = await CryptoUtils.hashPassword(password);
        await StorageUtils.savePasswordData(hash, salt);
        await StorageUtils.saveLoginStatus(true);
        
        hideLoader();
        showToast(translations[state.currentLang]['password_registered']);
        elements.newPassword.value = '';
        elements.confirmPassword.value = '';
        elements.registerSection.style.display = 'none';
        showBookmarks(); // Show bookmarks directly after successful registration
    });

    // Login
    elements.loginBtn.addEventListener('click', async () => {
        const password = elements.password.value;
        
        showLoader();
        
        const { hash, salt } = await StorageUtils.getPasswordData();
        
        if (!hash) {
            hideLoader();
            showToast(translations[state.currentLang]['no_password'], 'error');
            elements.showRegisterBtn.click();
            return;
        }
        
        const isValid = await CryptoUtils.verifyPassword(password, hash, salt);
        
        hideLoader();
        
        if (isValid) {
            // Encrypted vault: derive the key from the password (no-op when encryption is off).
            if (!(await Vault.unlock(password))) {
                showToast(translations[state.currentLang]['wrong_password'], 'error');
                return;
            }
            await StorageUtils.saveLoginStatus(true);
            await StorageUtils.recordSessionActivity(true); // Record activity on login
            elements.password.value = '';
            showBookmarks();
        } else {
            showToast(translations[state.currentLang]['wrong_password'], 'error');
        }
    });

    // Side panel / panic / open folder / password generator
    const spBtn = document.getElementById('side-panel-btn');
    const sidePanelApi = typeof chrome !== 'undefined' ? chrome['sidePanel'] : null;
    if (spBtn && sidePanelApi && typeof sidePanelApi['open'] === 'function' && location.search.indexOf('panel=1') === -1) {
        spBtn.style.display = '';
        spBtn.addEventListener('click', async () => {
            try {
                const win = await chrome.windows.getCurrent();
                await sidePanelApi['open']({ windowId: win.id });
                window.close();
            } catch (_e) { showToast('Side panel unavailable', 'error'); }
        });
    }
    const panicBtn = document.getElementById('panic-btn');
    if (panicBtn) panicBtn.addEventListener('click', async () => {
        await StorageUtils.saveLoginStatus(false);
        elements.logoutBtn.click();
        window.close();
    });
    const guideBtn = document.getElementById('guide-btn');
    if (guideBtn) guideBtn.addEventListener('click', () => {
        chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') });
    });
    const openFolderBtn = document.getElementById('open-folder-btn');
    if (openFolderBtn) openFolderBtn.addEventListener('click', () => {
        const folder = elements.folderSelect.value;
        const links = (state.bookmarks || []).filter((b) => (folder === 'all' || b.folder === folder) && StorageUtils.isSafeHttpUrl(b.url));
        if (!links.length) return;
        if (links.length > 10 && !confirm('Open ' + links.length + ' tabs?')) return;
        links.forEach((b) => chrome.tabs.create({ url: b.url, active: false }));
    });
    const genBtn = document.getElementById('gen-password-btn');
    if (genBtn) genBtn.addEventListener('click', () => {
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#\$%&*?';
        const buf = new Uint32Array(18); crypto.getRandomValues(buf);
        const pw = Array.from(buf, (n) => chars[n % chars.length]).join('');
        elements.newPassword.value = pw; elements.confirmPassword.value = pw;
        elements.newPassword.type = 'text'; elements.confirmPassword.type = 'text';
        elements.newPassword.dispatchEvent(new Event('input'));
        navigator.clipboard.writeText(pw).then(() => showToast('Password generated and copied - store it safely!')).catch(() => {});
    });

    // Logout
    elements.logoutBtn.addEventListener('click', async () => {
        await StorageUtils.saveLoginStatus(false);
        elements.password.value = '';
        elements.loginSection.style.display = 'block';
        elements.registerSection.style.display = 'none';
        elements.bookmarksSection.style.display = 'none';
        elements.welcomeScreen.style.display = 'none';
    });

    // Add bookmark
    const saveAllTabsBtn = document.getElementById('save-all-tabs-btn');
    if (saveAllTabsBtn) saveAllTabsBtn.addEventListener('click', async () => {
        const sel = document.getElementById('folder-select-add');
        const res = await new Promise((r) => chrome.runtime.sendMessage({ action: 'saveAllTabs', folder: sel ? sel.value : '' }, (x) => r(x || {})));
        if (res.success) {
            showToast(t('save_all_tabs') + ': +' + res.added + (res.skipped ? ' (' + res.skipped + ' skipped)' : ''));
            const rb = document.getElementById('refresh-btn'); if (rb) rb.click();
        } else {
            showToast(res.error || 'Failed', 'error');
        }
    });

    elements.addBookmarkBtn.addEventListener('click', async () => {
        const tabMeta = await refreshCurrentTabMeta();
        if (!tabMeta || !isSafeHttpUrl(tabMeta.url)) {
            showToast(t('invalid_url', 'Unsupported URL. Only HTTP/HTTPS pages can be saved.'), 'error');
            return;
        }

        const normalizedUrl = normalizeHttpUrl(tabMeta.url);
        const normalizedCanonical = canonicalUrl(normalizedUrl);
        if (!normalizedUrl || !normalizedCanonical) {
            showToast(t('invalid_url', 'Unsupported URL. Only HTTP/HTTPS pages can be saved.'), 'error');
            return;
        }

        const selectedFolder = elements.folderSelectAdd.value || state.folders[0]?.name;
        const userTagNames = elements.tagInput.value.split(',').map((tag) => tag.trim()).filter(Boolean);
        const suggestedTagNames = inferTagsFromMeta(normalizedUrl, tabMeta.title);
        const tagNames = mergeTags(userTagNames, suggestedTagNames);

        const bookmarkTags = [];
        for (const tagName of tagNames) {
            let tag = state.tags.find((entry) => entry.name.toLowerCase() === tagName.toLowerCase());
            if (!tag) {
                tag = {
                    id: CryptoUtils.generateUUID(),
                    name: tagName,
                    color: colorFromTagName(tagName)
                };
                state.tags.push(tag);
            }
            bookmarkTags.push(tag.name);
        }
        await StorageUtils.saveTags(state.tags);

        const favicon = tabMeta.favIconUrl || getFavicon(normalizedUrl);

        const newBookmark = {
            id: CryptoUtils.generateUUID(),
            title: tabMeta.title,
            url: normalizedUrl,
            folder: selectedFolder,
            tags: bookmarkTags,
            favicon,
            date: new Date().toLocaleDateString(state.currentLang, {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            }),
            timestamp: Date.now(),
            visitCount: 0,
            lastVisited: null
        };

        const alreadyExists = state.bookmarks.some((bookmark) => canonicalUrl(bookmark.url) === normalizedCanonical);
        if (alreadyExists) {
            showToast(translations[state.currentLang]['already_saved'], 'error');
            return;
        }

        state.bookmarks.push(newBookmark);
        await StorageUtils.saveBookmarks(state.bookmarks);

        elements.tagInput.value = '';
        state.activeSuggestedTags = inferTagsFromMeta(normalizedUrl, tabMeta.title);
        updateSmartTagSuggestions();

        refreshBookmarkView();
        showToast(t('saved_clean_link', 'Saved with smart cleanup and tags!'));
        await updateStats();
        loadTags();
    });

    // Show/hide all
    elements.showAllBtn.addEventListener('click', () => {
        state.allBookmarksHidden = false;
        filterBookmarks();
        elements.showAllBtn.classList.add('active');
        elements.hideAllBtn.classList.remove('active');
    });

    elements.hideAllBtn.addEventListener('click', () => {
        state.allBookmarksHidden = true;
        filterBookmarks();
        elements.hideAllBtn.classList.add('active');
        elements.showAllBtn.classList.remove('active');
    });

    // Refresh
    elements.refreshBtn.addEventListener('click', async () => {
        elements.refreshBtn.style.transform = 'rotate(360deg)';
        elements.refreshBtn.style.transition = 'transform 0.5s ease';
        
        state.bookmarks = await StorageUtils.getBookmarks();
        refreshBookmarkView();
        await updateStats();
        await refreshCurrentTabMeta();
        
        setTimeout(() => {
            elements.refreshBtn.style.transform = 'rotate(0deg)';
        }, 500);
    });

    // Stats modal
    elements.statsBtn.addEventListener('click', () => {
        updateStats();
        openModal(elements.statsModal);
    });

    // Backup modal
    elements.backupBtn.addEventListener('click', () => {
        loadBackups();
        openModal(elements.backupModal);
    });

    // Create backup
    elements.createBackupBtn.addEventListener('click', async () => {
        showLoader();
        await StorageUtils.createBackup();
        hideLoader();
        showToast(t('backup_created', 'Backup created!'));
        loadBackups();
    });

    // Auto backup toggle
    elements.autoBackupToggle.addEventListener('change', async () => {
        await StorageUtils.savePreferences({ autoBackup: elements.autoBackupToggle.checked });
        chrome.runtime.sendMessage({ action: 'setupAutoBackup' });
        showToast(elements.autoBackupToggle.checked
            ? t('auto_backup_enabled', 'Automatic backup enabled!')
            : t('auto_backup_disabled', 'Automatic backup disabled!')
        );
    });

    // Settings - open options page
    elements.settingsBtn.addEventListener('click', () => {
        try {
            const opened = chrome.runtime.openOptionsPage();
            if (opened && opened.catch) opened.catch(() => chrome.tabs.create({ url: chrome.runtime.getURL('options.html') }));
        } catch (_error) {
            chrome.tabs.create({ url: chrome.runtime.getURL('options.html') });
        }
    });

    // Search
    let searchTimeout;
    elements.searchBox.addEventListener('input', () => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(filterBookmarks, 300);
    });

    elements.tagInput.addEventListener('input', () => {
        updateSmartTagSuggestions();
    });

    // Folder selection color updates
    elements.folderSelect.addEventListener('change', (e) => {
        const selectedOption = e.target.options[e.target.selectedIndex];
        e.target.style.color = selectedOption.style.color || 'inherit';
        filterBookmarks();
    });

    elements.folderSelectAdd.addEventListener('change', (e) => {
        const selectedOption = e.target.options[e.target.selectedIndex];
        e.target.style.color = selectedOption.style.color || 'inherit';
    });

    // Sort buttons
    elements.sortDateBtn.addEventListener('click', () => {
        state.sortBy = 'date';
        updateSortButtons();
        refreshBookmarkView();
    });

    elements.sortNameBtn.addEventListener('click', () => {
        state.sortBy = 'name';
        updateSortButtons();
        refreshBookmarkView();
    });
    elements.sortVisitsBtn.addEventListener('click', () => {
        state.sortBy = 'visits';
        updateSortButtons();
        refreshBookmarkView();
    });

    function updateSortButtons() {
        [elements.sortDateBtn, elements.sortNameBtn, elements.sortVisitsBtn].forEach(btn => {
            btn.classList.remove('active');
        });
        
        if (state.sortBy === 'date') elements.sortDateBtn.classList.add('active');
        if (state.sortBy === 'name') elements.sortNameBtn.classList.add('active');
        if (state.sortBy === 'visits') elements.sortVisitsBtn.classList.add('active');
    }

    // New folder modal
    elements.newFolderBtn.addEventListener('click', () => {
        elements.folderName.value = '';
        openModal(elements.folderModal);
        elements.folderName.focus();
    });

    // Color selection
    document.querySelectorAll('.color-option').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.color-option').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            state.selectedFolderColor = btn.dataset.color;
            
            // Sync custom inputs
            if (elements.folderColorPicker) elements.folderColorPicker.value = btn.dataset.color;
            if (elements.folderColorHex) elements.folderColorHex.value = btn.dataset.color.replace('#', '');
        });
    });

    // Custom color picker logic
    if (elements.folderColorPicker) {
        elements.folderColorPicker.addEventListener('input', (e) => {
            const color = e.target.value;
            state.selectedFolderColor = color;
            if (elements.folderColorHex) elements.folderColorHex.value = color.replace('#', '');
            
            // Remove active state from predefined options
            document.querySelectorAll('.color-option').forEach(b => b.classList.remove('active'));
        });
    }

    if (elements.folderColorHex) {
        elements.folderColorHex.addEventListener('input', (e) => {
            let hex = e.target.value.trim();
            if (!hex.startsWith('#')) hex = '#' + hex;
            
            if (/^#[0-9A-F]{6}$/i.test(hex)) {
                state.selectedFolderColor = hex;
                if (elements.folderColorPicker) elements.folderColorPicker.value = hex;
                
                // Remove active state from predefined options
                document.querySelectorAll('.color-option').forEach(b => b.classList.remove('active'));
            }
        });
    }

    // Save folder
    elements.saveFolderBtn.addEventListener('click', async () => {
        const name = elements.folderName.value.trim();
        
        if (!name) return;
        
        if (state.folders.some(f => f.name.toLowerCase() === name.toLowerCase())) {
            showToast(translations[state.currentLang]['folder_exists'], 'error');
            return;
        }
        
        const newFolder = {
            id: CryptoUtils.generateUUID(),
            name: name,
            color: state.selectedFolderColor,
            isDefault: false
        };
        
        state.folders.push(newFolder);
        await StorageUtils.saveFolders(state.folders);
        
        updateFolderDropdowns();
        closeModal(elements.folderModal);
        showToast(translations[state.currentLang]['folder_add_success']);
    });

    // Delete folder
    elements.deleteFolderBtn.addEventListener('click', async () => {
        const selectedFolder = elements.folderSelect.value;
        
        if (selectedFolder === 'all') return;
        
        if (!confirm(translations[state.currentLang]['folder_delete_confirm'])) return;
        
        // Delete all bookmarks in this folder
        state.bookmarks = state.bookmarks.filter(b => b.folder !== selectedFolder);
        
        // Remove folder
        state.folders = state.folders.filter(f => f.name !== selectedFolder);
        
        await StorageUtils.saveBookmarks(state.bookmarks);
        await StorageUtils.saveFolders(state.folders);
        
        updateFolderDropdowns();
        refreshBookmarkView();
        showToast(translations[state.currentLang]['folder_delete_success']);
    });

    // Export
    elements.exportBtn.addEventListener('click', async () => {
        const data = await StorageUtils.exportAllData();
        
        if (data.bookmarks.length === 0) {
            showToast(translations[state.currentLang]['no_bookmarks'], 'error');
            return;
        }
        
        const dataStr = JSON.stringify(data, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
        const exportName = `PrivateLinkSaver_backup_${new Date().toISOString().slice(0, 10)}.json`;
        
        const link = document.createElement('a');
        link.href = dataUri;
        link.download = exportName;
        link.click();
        
        showToast(translations[state.currentLang]['export_success']);
    });

    // Toggle cloud password visibility
    if (elements.toggleCloudPassword) {
        elements.toggleCloudPassword.addEventListener('click', () => {
            const type = elements.cloudPassword.type === 'password' ? 'text' : 'password';
            elements.cloudPassword.type = type;
            setFaIcon(elements.toggleCloudPassword, type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash');
        });
    }

    // Cloud login
    if (elements.cloudLoginBtn) {
        elements.cloudLoginBtn.addEventListener('click', async () => {
            const email = elements.cloudEmail.value.trim();
            const password = elements.cloudPassword.value;
            
            if (!email || !password) {
                showToast('Please enter email and password', 'error');
                return;
            }

            showLoader();
            try {
                await CloudAuth.login(email, password);

                /* 
                const verified = await CloudAuth.isEmailVerified();
                if (!verified) {
                    await firebase.auth().signOut();
                    hideLoader();
                    showToast('Please verify your email address before logging in.', 'error');
                    return;
                }
                */

                // Cloud salt wins (it is what the stored cloud data was encrypted with), then local, then new.
                let salt = await CloudStorage.getCloudSalt();
                if (!salt) {
                    const cloudKeyData = await StorageUtils.get(['cloudEncryptionSalt']);
                    if (cloudKeyData.cloudEncryptionSalt && cloudKeyData.cloudEncryptionSalt !== 'derived') {
                        salt = cloudKeyData.cloudEncryptionSalt;
                    }
                }
                if (!salt) salt = generateSalt();
                state.cloudEncryptionKey = await getCloudEncryptionKey(password, salt);
                state.cloudPassword = password;
                state.cloudSalt = salt;
                state.cloudLoggedIn = true;
                await StorageUtils.set({ cloudEncryptionSalt: salt });
                hideLoader();
                showToast('Logged in successfully!');
                await updateCloudUI();
                await showBookmarks();
            } catch (error) {
                hideLoader();
                showToast(error.message, 'error');
            }
        });
    }

    // Cloud register
    if (elements.cloudRegisterBtn) {
        elements.cloudRegisterBtn.addEventListener('click', async () => {
            const email = elements.cloudEmail.value.trim();
            const password = elements.cloudPassword.value;
            
            if (!email || !password) {
                showToast('Please enter email and password', 'error');
                return;
            }

            if (password.length < 6) {
                showToast('Password must be at least 6 characters', 'error');
                return;
            }

            showLoader();
            try {
                await CloudAuth.register(email, password);
                const salt = generateSalt();
                state.cloudEncryptionKey = await getCloudEncryptionKey(password, salt);
                state.cloudPassword = password;
                state.cloudSalt = salt;
                state.cloudLoggedIn = true;
                await StorageUtils.set({ cloudEncryptionSalt: salt });
                hideLoader();
                showToast('Account created! Please check your email for the verification link.');

                // Show verification dialog
                await showEmailVerificationDialogPopup(email, password, salt);
            } catch (error) {
                hideLoader();
                showToast(error.message, 'error');
            }
        });
    }

    // Email verification dialog for popup
    async function showEmailVerificationDialogPopup(email, password, salt) {
        const overlay = document.createElement('div');
        overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:10000;display:flex;align-items:center;justify-content:center;';

        const dialog = document.createElement('div');
        dialog.style.cssText = 'background:#fff;border-radius:16px;padding:32px;max-width:420px;width:90%;box-shadow:0 8px 32px rgba(0,0,0,0.3);text-align:center;color:#1e293b;font-family:Inter,sans-serif;';

        const emoji = document.createElement('div');
        emoji.style.cssText = 'font-size:48px;margin-bottom:16px;';
        emoji.textContent = 'ðŸ“§';

        const title = document.createElement('h3');
        title.style.cssText = 'margin:0 0 8px;font-size:20px;';
        title.textContent = 'Verify Your Email';

        const p1 = document.createElement('p');
        p1.style.cssText = 'margin:0 0 8px;font-size:14px;color:#64748b;line-height:1.5;';
        p1.appendChild(document.createTextNode('A verification email has been sent to'));
        p1.appendChild(document.createElement('br'));
        const emailStrong = document.createElement('strong');
        emailStrong.textContent = email;
        p1.appendChild(emailStrong);

        const p2 = document.createElement('p');
        p2.style.cssText = 'margin:0 0 24px;font-size:13px;color:#64748b;';
        p2.textContent = 'Click the link in the email, then confirm below.';

        const statusEl = document.createElement('div');
        statusEl.id = 'popup-verify-status';
        statusEl.style.cssText = 'margin-bottom:16px;font-size:13px;min-height:20px;';

        const btnRow = document.createElement('div');
        btnRow.style.cssText = 'display:flex;gap:12px;';

        const cancelBtn = document.createElement('button');
        cancelBtn.id = 'popup-verify-cancel-btn';
        cancelBtn.style.cssText = 'flex:1;padding:12px;border:1px solid #e2e8f0;border-radius:8px;background:transparent;color:#64748b;font-size:14px;font-weight:600;cursor:pointer;font-family:Inter,sans-serif;';
        cancelBtn.textContent = 'Cancel';

        const confirmBtn = document.createElement('button');
        confirmBtn.id = 'popup-verify-confirm-btn';
        confirmBtn.style.cssText = 'flex:1;padding:12px;border:none;border-radius:8px;background:linear-gradient(135deg,#0ea5e9,#38bdf8);color:white;font-size:14px;font-weight:600;cursor:pointer;font-family:Inter,sans-serif;';
        confirmBtn.textContent = "I've Verified";

        btnRow.appendChild(cancelBtn);
        btnRow.appendChild(confirmBtn);
        dialog.appendChild(emoji);
        dialog.appendChild(title);
        dialog.appendChild(p1);
        dialog.appendChild(p2);
        dialog.appendChild(statusEl);
        dialog.appendChild(btnRow);

        overlay.appendChild(dialog);
        document.body.appendChild(overlay);

        return new Promise((resolve) => {
            cancelBtn.addEventListener('click', () => {
                document.body.removeChild(overlay);
                resolve(false);
            });

            confirmBtn.addEventListener('click', async () => {
                confirmBtn.disabled = true;
                confirmBtn.textContent = 'Checking...';
                statusEl.textContent = '';
                statusEl.style.color = '';

                try {
                    const verified = await CloudAuth.isEmailVerified();
                    if (verified) {
                        statusEl.textContent = 'Email verified! You can now use cloud sync.';
                        statusEl.style.color = '#10b981';
                        setTimeout(async () => {
                            document.body.removeChild(overlay);
                            await updateCloudUI();
                            resolve(true);
                        }, 1000);
                    } else {
                        statusEl.textContent = 'Email not verified yet. Please check your inbox and click the verification link.';
                        statusEl.style.color = '#ef4444';
                        confirmBtn.disabled = false;
                        confirmBtn.textContent = "I've Verified";
                    }
                } catch (error) {
                    statusEl.textContent = 'Check failed: ' + error.message;
                    statusEl.style.color = '#ef4444';
                    confirmBtn.disabled = false;
                    confirmBtn.textContent = "I've Verified";
                }
            });
        });
    }

    // Cloud forgot password
    if (elements.cloudForgotBtn) {
        elements.cloudForgotBtn.addEventListener('click', async () => {
            const email = elements.cloudEmail.value.trim();
            if (!email) {
                showToast('Please enter your email address', 'error');
                return;
            }

            try {
                await CloudAuth.resetPassword(email);
                showToast('Password reset email sent!');
            } catch (error) {
                showToast(error.message, 'error');
            }
        });
    }

    // Back to login button
    if (elements.backToLoginBtn) {
        elements.backToLoginBtn.addEventListener('click', () => {
            elements.cloudAccountSection.querySelector('.cloud-form').style.display = 'block';
            elements.cloudAccountSection.querySelector('.auth-footer').style.display = 'none';
        });
    }

    // Helper to derive encryption key from password
    async function getCloudEncryptionKey(password, salt) {
        const encoder = new TextEncoder();
        
        return await crypto.subtle.deriveKey(
            {
                name: 'PBKDF2',
                salt: encoder.encode(salt),
                iterations: 100000,
                hash: 'SHA-256'
            },
            await crypto.subtle.importKey(
                'raw',
                encoder.encode(password),
                { name: 'PBKDF2', length: 256 },
                false,
                ['deriveKey']
            ),
            { name: 'AES-GCM', length: 256 },
            true,
            ['encrypt', 'decrypt']
        );
    }

    function generateSalt() {
        const array = crypto.getRandomValues(new Uint8Array(16));
        return Array.from(array).map(b => b.toString(16).padStart(2, '0')).join('');
    }

    async function updateCloudUI() {
        // Cloud sync UI is now only available in the settings/options page.
        if (elements.cloudSyncStatus) {
            elements.cloudSyncStatus.style.display = 'none';
        }
    }

    // Open edit bookmark modal
    function openEditBookmarkModal(bookmark) {
        // Ensure bookmark has an ID for reliable tracking
        if (!bookmark.id) {
            bookmark.id = CryptoUtils.generateUUID();
        }
        state.editingBookmarkId = bookmark.id;
        
        elements.editBookmarkTitle.value = bookmark.title;
        elements.editBookmarkUrl.value = bookmark.url;
        openModal(elements.editBookmarkModal);
        setTimeout(() => elements.editBookmarkTitle.focus(), 100);
    }

    // Save edited bookmark
    elements.saveBookmarkEditBtn.addEventListener('click', async () => {
        const newTitle = elements.editBookmarkTitle.value.trim();
        const newUrl = elements.editBookmarkUrl.value.trim();
        
        if (!newTitle || !newUrl) return;

        if (!isSafeHttpUrl(newUrl)) {
            showToast(t('invalid_url', 'Unsupported URL. Only HTTP/HTTPS links are allowed.'), 'error');
            return;
        }

        const normalizedUrl = normalizeHttpUrl(newUrl);
        const normalizedCanonical = canonicalUrl(newUrl);
        if (!normalizedUrl || !normalizedCanonical) {
            showToast(t('invalid_url', 'Unsupported URL. Only HTTP/HTTPS links are allowed.'), 'error');
            return;
        }

        const duplicate = state.bookmarks.some((bookmark) => {
            if (bookmark.id === state.editingBookmarkId) return false;
            return canonicalUrl(bookmark.url) === normalizedCanonical;
        });
        if (duplicate) {
            showToast(translations[state.currentLang]['already_saved'], 'error');
            return;
        }
        
        // Find bookmark
        const bookmarkIndex = state.bookmarks.findIndex(b => b.id === state.editingBookmarkId);
        
        if (bookmarkIndex !== -1) {
            state.bookmarks[bookmarkIndex].title = newTitle;
            state.bookmarks[bookmarkIndex].url = normalizedUrl;
            
            await StorageUtils.saveBookmarks(state.bookmarks);
            refreshBookmarkView();
            closeModal(elements.editBookmarkModal);
            showToast(translations[state.currentLang]['save'] + '!');
        } else {
            // Fallback: if ID lookup fails (shouldn't happen if we set it), try to find by other means or just close
             closeModal(elements.editBookmarkModal);
        }
    });
    
    // Allow Enter key to save
    elements.editBookmarkTitle.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') elements.saveBookmarkEditBtn.click();
    });
    
    elements.editBookmarkUrl.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') elements.saveBookmarkEditBtn.click();
    });

    // Import
    elements.importBtn.addEventListener('click', () => {
        elements.fileInput.click();
    });

    elements.fileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = async (e) => {
            try {
                const importedData = JSON.parse(e.target.result);
                
                if (!importedData.bookmarks || !Array.isArray(importedData.bookmarks)) {
                    throw new Error('Invalid format');
                }
                
                const merge = confirm(t('merge_import_confirm', 'Do you want to merge with existing bookmarks? Click Cancel to replace all.'));
                
                showLoader();
                await StorageUtils.importData(importedData, merge);
                
                state.bookmarks = await StorageUtils.getBookmarks();
                state.folders = await StorageUtils.getFolders();
                state.tags = await StorageUtils.getTags();
                
                updateFolderDropdowns();
                updateTagList();
                refreshBookmarkView();
                await updateStats();
                
                hideLoader();
                showToast(translations[state.currentLang]['import_success']);
            } catch (error) {
                hideLoader();
                showToast(translations[state.currentLang]['import_error'], 'error');
            }
        };
        reader.readAsText(file);
        elements.fileInput.value = '';
    });

    // ===== Multi-select, bulk actions and drag & drop to folders =====
    const bulkBar = document.getElementById('bulk-bar');
    const bulkCount = document.getElementById('bulk-count');
    const bulkAllBtn = document.getElementById('bulk-all-btn');
    const bulkMove = document.getElementById('bulk-move');
    const bulkTagInput = document.getElementById('bulk-tag-input');
    const bulkTagBtn = document.getElementById('bulk-tag-btn');
    const bulkDeleteBtn = document.getElementById('bulk-delete-btn');
    const selectModeBtn = document.getElementById('select-mode-btn');
    const dropBar = document.getElementById('folder-drop-bar');

    function updateBulkBar() {
        const existing = new Set(state.bookmarks.map((b) => b.id));
        state.selectedIds.forEach((id) => { if (!existing.has(id)) state.selectedIds.delete(id); });
        bulkBar.hidden = !state.selectMode;
        selectModeBtn.classList.toggle('active', state.selectMode);
        bulkCount.textContent = `${state.selectedIds.size} ${t('selected_count', 'selected')}`;
        bulkAllBtn.textContent = t('select_all', 'All');
        const none = state.selectedIds.size === 0;
        [bulkMove, bulkTagInput, bulkTagBtn, bulkDeleteBtn].forEach((el) => { el.disabled = none; });
    }

    function fillBulkMove() {
        clearChildren(bulkMove);
        const placeholder = document.createElement('option');
        placeholder.value = '';
        placeholder.textContent = t('move_to', 'Move to...');
        bulkMove.appendChild(placeholder);
        state.folders.forEach((folder) => {
            const option = document.createElement('option');
            option.value = folder.name;
            option.textContent = folder.name;
            bulkMove.appendChild(option);
        });
    }

    function showFolderDropBar() {
        clearChildren(dropBar);
        const hint = document.createElement('span');
        hint.className = 'folder-drop-hint';
        hint.textContent = t('drop_to_move', 'Drop on a folder to move');
        dropBar.appendChild(hint);
        state.folders.forEach((folder) => {
            const chip = document.createElement('div');
            chip.className = 'folder-drop-chip';
            chip.textContent = folder.name;
            chip.style.borderColor = folder.color;
            chip.style.color = folder.color;
            chip.addEventListener('dragover', (e) => {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
                chip.classList.add('over');
            });
            chip.addEventListener('dragleave', () => chip.classList.remove('over'));
            chip.addEventListener('drop', async (e) => {
                e.preventDefault();
                chip.classList.remove('over');
                hideFolderDropBar();
                await moveBookmarks(state.dragIds, folder.name);
            });
            dropBar.appendChild(chip);
        });
        dropBar.classList.add('visible');
    }

    function hideFolderDropBar() {
        dropBar.classList.remove('visible');
    }

    async function moveBookmarks(ids, folderName) {
        const wanted = new Set(ids);
        let moved = 0;
        state.bookmarks.forEach((b) => {
            if (wanted.has(b.id) && b.folder !== folderName) {
                b.folder = folderName;
                moved += 1;
            }
        });
        if (!moved) return;
        await StorageUtils.saveBookmarks(state.bookmarks);
        state.selectedIds.clear();
        refreshBookmarkView();
        showToast(`${t('bulk_moved', 'Moved')}: ${moved}`);
    }

    async function bulkAddTags() {
        const names = mergeTags(bulkTagInput.value.split(',').map((tagName) => tagName.trim()));
        if (!names.length || !state.selectedIds.size) return;
        const canonical = names.map((name) => {
            let tag = state.tags.find((entry) => entry.name.toLowerCase() === name.toLowerCase());
            if (!tag) {
                tag = { id: CryptoUtils.generateUUID(), name, color: colorFromTagName(name) };
                state.tags.push(tag);
            }
            return tag.name;
        });
        state.bookmarks.forEach((b) => {
            if (state.selectedIds.has(b.id)) b.tags = mergeTags(b.tags || [], canonical);
        });
        await StorageUtils.saveTags(state.tags);
        await StorageUtils.saveBookmarks(state.bookmarks);
        bulkTagInput.value = '';
        updateTagList();
        refreshBookmarkView();
        showToast(`${t('bulk_tagged', 'Tagged')}: ${state.selectedIds.size}`);
    }

    async function bulkDelete() {
        const ids = new Set(state.selectedIds);
        if (!ids.size || !confirm(t('bulk_delete_confirm', 'Delete the selected bookmarks? A safety backup is created first.'))) return;
        try { await StorageUtils.createBackup(); } catch (_error) { /* storage full: continue, the user confirmed */ }
        state.bookmarks = state.bookmarks.filter((b) => !ids.has(b.id));
        await StorageUtils.saveBookmarks(state.bookmarks);
        state.selectedIds.clear();
        refreshBookmarkView();
        showToast(`${t('bulk_deleted', 'Deleted')}: ${ids.size}`);
        await updateStats();
    }

    selectModeBtn.addEventListener('click', () => {
        state.selectMode = !state.selectMode;
        state.selectedIds.clear();
        refreshBookmarkView();
    });
    bulkAllBtn.addEventListener('click', () => {
        state.visibleIds.forEach((id) => state.selectedIds.add(id));
        refreshBookmarkView();
    });
    bulkMove.addEventListener('change', async () => {
        const target = bulkMove.value;
        bulkMove.value = '';
        if (target) await moveBookmarks([...state.selectedIds], target);
    });
    bulkTagBtn.addEventListener('click', bulkAddTags);
    bulkTagInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') bulkAddTags(); });
    bulkDeleteBtn.addEventListener('click', bulkDelete);

    // Close modals
    document.querySelectorAll('.close-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            this.closest('.modal').classList.remove('active');
        });
    });

    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'p') {
            e.preventDefault();
            openCommandPalette();
            return;
        }

        // Ctrl/Cmd + K - focus search
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            e.stopPropagation();
            elements.searchBox.focus();
        }
        
        // Escape - clear search or close command palette
        if (e.key === 'Escape' && elements.commandPaletteModal.classList.contains('active')) {
            closeModal(elements.commandPaletteModal);
            return;
        }

        if (e.key === 'Escape' && document.activeElement === elements.searchBox) {
            elements.searchBox.value = '';
            filterBookmarks();
            elements.searchBox.blur();
        }
        
        // Ctrl/Cmd + N - new folder
        if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
            e.preventDefault();
            e.stopPropagation();
            elements.newFolderBtn.click();
        }
        
        // Ctrl/Cmd + D - add bookmark
        if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
            e.preventDefault();
            e.stopPropagation();
            elements.addBookmarkBtn.click();
        }
    });

    // Enter key handlers
    elements.password.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') elements.loginBtn.click();
    });

    elements.newPassword.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') elements.confirmPassword.focus();
    });

    elements.confirmPassword.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') elements.registerBtn.click();
    });

    elements.folderName.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') elements.saveFolderBtn.click();
    });

    const versionText = document.getElementById('popup-version-text');
    if (versionText) versionText.textContent = 'v' + chrome.runtime.getManifest().version;

    // Initialize
    await initTheme();
    applyTranslation(state.currentLang);
    await loadFolders();
    await loadTags();
    await refreshCurrentTabMeta();
    await updateCloudUI();
    
    // Listen for messages from other parts of the extension (e.g., options page)
    chrome.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
        if (request.action === 'languageChanged') {
            applyTranslation(request.language);
            await loadFolders(); // Reload folders to update translated names
            refreshBookmarkView();
        } else if (request.action === 'focusSearch') {
            setTimeout(() => elements.searchBox.focus(), 100);
        }
    });

    // Another context (hotkey/context-menu save, options import) changed the links: reload so a later
    // save from this popup does not overwrite them with a stale list.
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && changes.showFavicons) {
            state.showFavicons = changes.showFavicons.newValue !== false;
            refreshBookmarkView();
        }
        if (area !== 'local' || !(changes.bookmarks || changes.vaultBlob)) return;
        if (elements.bookmarksSection.style.display !== 'block') return;
        StorageUtils.getBookmarks().then((list) => {
            state.bookmarks = list;
            refreshBookmarkView();
        }).catch(() => {});
    });

    // Check login status
    const isLoggedIn = await StorageUtils.getLoginStatus();
    const { hash } = await StorageUtils.getPasswordData();
    const prefs = await StorageUtils.getPreferences();
    
    // If a password hash exists, we should either show bookmarks or the login screen
    if (hash) {
        if (isLoggedIn) {
            // Check if session has expired (auto logout)
            const autoLogoutResult = await StorageUtils.enforceAutoLogout();
            if (autoLogoutResult.expired) {
                // Session expired - show login
                elements.loginSection.style.display = 'block';
                elements.welcomeScreen.style.display = 'none';
                elements.registerSection.style.display = 'none';
                elements.bookmarksSection.style.display = 'none';
                const mins = autoLogoutResult.minutes;
                showToast(`Auto-locked after ${mins} minute${mins !== 1 ? 's' : ''} of inactivity`, 'warning');
                await updateStats();
            } else if (prefs.firstTime) {
                showWelcomeScreen();
                await StorageUtils.savePreferences({ firstTime: false });
            } else {
                showBookmarks();
            }
        } else {
            // Not logged in but password exists -> Show login section
            elements.loginSection.style.display = 'block';
            elements.welcomeScreen.style.display = 'none';
            elements.registerSection.style.display = 'none';
            elements.bookmarksSection.style.display = 'none';
            await updateStats();
        }
    } else {
        // No password yet -> New installation flow
        await StorageUtils.savePreferences({ firstTime: true });
        showWelcomeScreen();
    }

    // Start session activity tracking (updates sessionLastActiveAt on user interaction)
    StorageUtils.initializeSessionActivityTracking();

    // Periodically check if auto logout should fire (every 30 seconds)
    setInterval(async () => {
        const loggedIn = await StorageUtils.getLoginStatus();
        if (!loggedIn) return;
        const result = await StorageUtils.enforceAutoLogout();
        if (result.expired) {
            const mins = result.minutes;
            showToast(`Auto-locked after ${mins} minute${mins !== 1 ? 's' : ''} of inactivity`, 'warning');
            elements.loginSection.style.display = 'block';
            elements.bookmarksSection.style.display = 'none';
            elements.welcomeScreen.style.display = 'none';
            elements.registerSection.style.display = 'none';
        }
    }, 30000);

    // ===== Chrome Bookmarks Import =====

    async function checkAndRequestBookmarksPermission() {
        return new Promise((resolve) => {
            chrome.permissions.contains({ permissions: ['bookmarks'] }, (granted) => {
                if (granted) { resolve(true); return; }
                chrome.permissions.request({ permissions: ['bookmarks'] }, (approved) => {
                    if (!approved) {
                        showToast(t('bookmarks_permission_required', 'Permission required to access Chrome bookmarks'), 'error');
                    }
                    resolve(approved);
                });
            });
        });
    }

    async function openChromeBookmarksModal() {
        const granted = await checkAndRequestBookmarksPermission();
        if (!granted) return;

        const treeContainer = document.getElementById('chrome-bookmarks-tree');
        clearChildren(treeContainer);

        try {
            chrome.bookmarks.getTree((tree) => {
                renderBookmarkTree(tree, treeContainer);
                document.getElementById('chrome-bookmarks-modal').classList.add('active');
            });
        } catch (err) {
            showToast(t('save_error', 'Could not load Chrome bookmarks'), 'error');
        }
    }

    function closeChromeBookmarksModal() {
        document.getElementById('chrome-bookmarks-modal').classList.remove('active');
        clearChildren(document.getElementById('chrome-bookmarks-tree'));
    }

    const chromeImportBtn = document.getElementById('chrome-import-btn');
    if (isAndroid) chromeImportBtn.style.display = 'none'; // no bookmarks API on Android
    chromeImportBtn.addEventListener('click', openChromeBookmarksModal);
    document.getElementById('chrome-bookmarks-close-btn').addEventListener('click', closeChromeBookmarksModal);

    function folderHasValidLinks(node) {
        if (node.url) return StorageUtils.isSafeHttpUrl(node.url);
        return (node.children || []).some(folderHasValidLinks);
    }

    function collectValidLinks(node) {
        if (node.url) {
            return StorageUtils.isSafeHttpUrl(node.url) ? [node] : [];
        }
        return (node.children || []).flatMap(collectValidLinks);
    }

    function renderBookmarkTree(nodes, container, parentFolderTitle = null) {
        nodes.forEach((node) => {
            const el = renderBookmarkNode(node, parentFolderTitle);
            if (el) container.appendChild(el);
        });
    }

    function renderBookmarkNode(node, parentFolderTitle = null) {
        const wrapper = document.createElement('div');
        wrapper.className = 'chrome-tree-node';

        const currentFolderTitle = node.url ? parentFolderTitle : (node.title || parentFolderTitle);

        if (!node.url) {
            // Folder node
            const row = document.createElement('div');
            row.className = 'chrome-tree-folder';

            const toggle = document.createElement('button');
            toggle.className = 'chrome-tree-toggle';
            toggle.textContent = 'â–¶';

            const icon = document.createElement('i');
            icon.className = 'chrome-tree-icon fas fa-folder';

            const title = document.createElement('span');
            title.className = 'chrome-tree-title';
            title.textContent = node.title || 'Folder';

            const actions = document.createElement('div');
            actions.className = 'chrome-node-actions';

            if (folderHasValidLinks(node)) {
                const importBtn = document.createElement('button');
                importBtn.className = 'chrome-import-btn-sm';
                importBtn.textContent = t('import_folder', 'Import Folder');
                importBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    importFolder(node);
                });
                actions.appendChild(importBtn);
            }

            row.appendChild(toggle);
            row.appendChild(icon);
            row.appendChild(title);
            row.appendChild(actions);

            const children = document.createElement('div');
            children.className = 'chrome-tree-children';
            renderBookmarkTree(node.children || [], children, currentFolderTitle);

            toggle.addEventListener('click', (e) => {
                e.stopPropagation();
                const isOpen = children.classList.toggle('open');
                toggle.classList.toggle('open', isOpen);
                icon.className = `chrome-tree-icon fas fa-folder${isOpen ? '-open' : ''}`;
            });

            wrapper.appendChild(row);
            wrapper.appendChild(children);
        } else {
            // Link node
            if (!StorageUtils.isSafeHttpUrl(node.url)) return null;

            const row = document.createElement('div');
            row.className = 'chrome-tree-link';

            const spacer = document.createElement('span');
            spacer.style.width = '16px';
            spacer.style.flexShrink = '0';

            const favicon = document.createElement('img');
            favicon.className = 'chrome-tree-favicon';
            try {
                const domain = new URL(node.url).hostname;
                if (!state.showFavicons) throw new Error('icons off');
                favicon.src = `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=16`;
            } catch (_) {
                favicon.style.display = 'none';
            }
            favicon.alt = '';

            const title = document.createElement('span');
            title.className = 'chrome-tree-title';
            title.textContent = node.title || node.url;

            const actions = document.createElement('div');
            actions.className = 'chrome-node-actions';

            const importBtn = document.createElement('button');
            importBtn.className = 'chrome-import-btn-sm';
            importBtn.textContent = t('import_link', 'Import Link');
            importBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                importSingleLink(node, currentFolderTitle);
            });
            actions.appendChild(importBtn);

            row.appendChild(spacer);
            row.appendChild(favicon);
            row.appendChild(title);
            row.appendChild(actions);
            wrapper.appendChild(row);
        }

        return wrapper;
    }

    async function importSingleLink(node, overrideFolderName = null) {
        const normalizedUrl = StorageUtils.normalizeBookmarkUrl(node.url);
        if (!normalizedUrl) return;

        const existing = await StorageUtils.getBookmarks();
        const canonical = StorageUtils.canonicalUrl(normalizedUrl);
        const isDuplicate = existing.some((b) => StorageUtils.canonicalUrl(b.url) === canonical);

        if (isDuplicate) {
            showToast(t('link_already_exists', 'Link already exists'), 'warning');
            return;
        }

        const folderName = overrideFolderName || elements.folderSelectAdd.value || state.folders[0]?.name || 'General';
        const newBookmark = {
            id: CryptoUtils.generateUUID(),
            title: String(node.title || normalizedUrl).trim(),
            url: normalizedUrl,
            folder: folderName,
            tags: [],
            favicon: null,
            date: new Date().toLocaleDateString('en', { year: 'numeric', month: 'short', day: 'numeric' }),
            timestamp: Date.now(),
            visitCount: 0,
            lastVisited: null
        };

        await StorageUtils.saveBookmarks([...existing, newBookmark]);
        await refreshAfterImport();
        showToast(t('import_success', 'Imported!'), 'success');
    }

    async function importFolder(node) {
        const validLinks = collectValidLinks(node);
        if (validLinks.length === 0) {
            showToast(t('folder_empty', 'Folder has no importable links'), 'info');
            return;
        }

        showLoader();

        // Ensure folder exists
        const existingFolders = await StorageUtils.getFolders();
        const folderName = String(node.title || 'Imported').trim();
        const folderExists = existingFolders.some((f) => f.name.toLowerCase() === folderName.toLowerCase());

        if (!folderExists) {
            const newFolder = {
                id: CryptoUtils.generateUUID(),
                name: folderName,
                color: '#3498db',
                isDefault: false,
                key: undefined
            };
            const updatedFolders = [...existingFolders, newFolder];
            await StorageUtils.saveFolders(updatedFolders);
            state.folders = updatedFolders; // Update state immediately
        }

        // Import links
        const existing = await StorageUtils.getBookmarks();
        const existingCanonicals = new Set(existing.map((b) => StorageUtils.canonicalUrl(b.url)));
        let imported = 0;
        let skipped = 0;
        const toAdd = [];

        for (const linkNode of validLinks) {
            const normalizedUrl = StorageUtils.normalizeBookmarkUrl(linkNode.url);
            if (!normalizedUrl) { skipped++; continue; }
            const canonical = StorageUtils.canonicalUrl(normalizedUrl);
            if (existingCanonicals.has(canonical)) { skipped++; continue; }
            existingCanonicals.add(canonical);
            
            // Find parent folder name for this specific link if we want to be even smarter
            // But for now, as requested, we put everything in the folder they clicked to import
            
            toAdd.push({
                id: CryptoUtils.generateUUID(),
                title: String(linkNode.title || normalizedUrl).trim(),
                url: normalizedUrl,
                folder: folderName,
                tags: [],
                favicon: null,
                date: new Date().toLocaleDateString('en', { year: 'numeric', month: 'short', day: 'numeric' }),
                timestamp: Date.now(),
                visitCount: 0,
                lastVisited: null
            });
            imported++;
        }

        if (toAdd.length > 0) {
            await StorageUtils.saveBookmarks([...existing, ...toAdd]);
        }
        
        await refreshAfterImport();
        hideLoader();
        showToast(`${t('import_success', 'Imported')}: ${imported} | ${t('skipped', 'Skipped')}: ${skipped}`, imported > 0 ? 'success' : 'info');
    }

    async function refreshAfterImport() {
        state.bookmarks = await StorageUtils.getBookmarks();
        state.folders = await StorageUtils.getFolders();
        updateFolderDropdowns();
        refreshBookmarkView();
        await updateStats();
    }

});

// Pastel folder chips (mirrors the hidden #folder-select)
(function () {
    const sel = document.getElementById('folder-select');
    const box = document.getElementById('folder-chips');
    if (!sel || !box) return;
    const tints = ['#ffd9c7', '#e3d8ff', '#cdf3e4', '#ffe6a8', '#d4e6ff', '#ffd1e0'];
    function render() {
        box.textContent = '';
        Array.from(sel.options).forEach((opt, i) => {
            const chip = document.createElement('button');
            chip.type = 'button';
            chip.className = 'folder-chip' + (opt.value === sel.value ? ' active' : '');
            chip.style.setProperty('--chip-tint', tints[i % tints.length]);
            chip.textContent = (opt.value === 'all' ? '' : '📁 ') + opt.textContent;
            chip.addEventListener('click', () => {
                sel.value = opt.value;
                sel.dispatchEvent(new Event('change', { bubbles: true }));
                render();
            });
            box.appendChild(chip);
        });
    }
    new MutationObserver(render).observe(sel, { childList: true });
    sel.addEventListener('change', render);
    render();

    // Drag-to-scroll & mousewheel horizontal scroll for horizontal bars
    function enableDragScroll(el) {
        if (!el) return;
        let isDown = false, startX = 0, scrollStart = 0, dragged = false;
        el.addEventListener('mousedown', (e) => {
            if (e.target.tagName === 'SELECT') return;
            isDown = true; dragged = false;
            startX = e.pageX - el.offsetLeft;
            scrollStart = el.scrollLeft;
        });
        window.addEventListener('mouseup', () => { isDown = false; });
        el.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            const walk = (e.pageX - el.offsetLeft) - startX;
            if (Math.abs(walk) > 4) dragged = true;
            if (dragged) { e.preventDefault(); el.scrollLeft = scrollStart - walk; }
        });
        el.addEventListener('click', (e) => {
            if (dragged) { e.preventDefault(); e.stopPropagation(); dragged = false; }
        }, true);
        el.addEventListener('wheel', (e) => {
            if (el.scrollWidth > el.clientWidth && Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
                e.preventDefault();
                el.scrollLeft += e.deltaY;
            }
        }, { passive: false });
    }
    enableDragScroll(document.querySelector('.data-actions'));
    enableDragScroll(document.querySelector('.sort-controls'));
})();