# Requirements Document

## Introduction

This feature adds a "Import from Chrome" capability to the PrivateLinkSaver extension. It allows users to browse their native Chrome bookmarks directly inside the extension popup using the `chrome.bookmarks` API, and import either individual links or entire folders (with all their links) into PrivateLinkSaver. The optional `bookmarks` permission is already declared in `manifest.json` but currently unused. When a folder is imported, a matching folder is created in PrivateLinkSaver (preserving the Chrome folder name) and all valid HTTP/HTTPS links inside it are saved. Duplicate URLs are silently skipped.

## Glossary

- **Chrome_Bookmarks_API**: The `chrome.bookmarks` browser API used to read the user's native Chrome bookmark tree.
- **Bookmark_Tree**: The hierarchical structure of Chrome bookmarks returned by `chrome.bookmarks.getTree()`, consisting of nodes that are either folders or links.
- **Bookmark_Node**: A single entry in the Chrome bookmark tree; either a folder (no `url` property) or a link (has a `url` property).
- **Chrome_Bookmarks_Modal**: The new modal dialog added to `popup.html` that displays the Chrome bookmark tree and allows the user to select items to import.
- **Import_Button**: The new "Import from Chrome" button added to the `data-actions` section of the popup.
- **Permission_Manager**: The logic that requests the optional `bookmarks` permission at runtime via `chrome.permissions.request()` if it has not already been granted.
- **Importer**: The JavaScript logic in `popup.js` responsible for reading the Chrome bookmark tree, rendering it in the modal, and executing import operations.
- **StorageUtils**: The existing `StorageUtils` object in `scripts/storage.js` used to persist bookmarks and folders via `chrome.storage.local`.
- **Duplicate_Detector**: The deduplication logic inside `StorageUtils.saveBookmarks()` that prevents the same canonical URL from being stored twice.

## Requirements

### Requirement 1: Import Button

**User Story:** As a user, I want an "Import from Chrome" button in the data-actions area, so that I can easily start the Chrome bookmarks import flow.

#### Acceptance Criteria

1. THE Popup SHALL display an "Import from Chrome" button inside the existing `data-actions` section, alongside the Export, Import, and Backup buttons.
2. WHEN the user clicks the Import_Button, THE Permission_Manager SHALL check whether the `bookmarks` optional permission has already been granted.
3. IF the `bookmarks` permission has not been granted, THEN THE Permission_Manager SHALL call `chrome.permissions.request({ permissions: ['bookmarks'] })` to prompt the user.
4. IF the user denies the permission request, THEN THE Importer SHALL display a toast notification informing the user that the permission is required and abort the import flow.
5. WHEN the `bookmarks` permission is granted, THE Importer SHALL open the Chrome_Bookmarks_Modal.

### Requirement 2: Chrome Bookmarks Modal

**User Story:** As a user, I want to see my Chrome bookmarks in a tree view inside the extension, so that I can browse and select what to import.

#### Acceptance Criteria

1. THE Chrome_Bookmarks_Modal SHALL be a modal dialog consistent in style with the existing modals in `popup.html` (same `.modal` / `.modal-content` / `.modal-header` / `.modal-body` structure).
2. WHEN the Chrome_Bookmarks_Modal opens, THE Importer SHALL call `chrome.bookmarks.getTree()` and render the result as a collapsible tree view.
3. THE Chrome_Bookmarks_Modal SHALL display folder nodes with a folder icon and an expand/collapse toggle.
4. THE Chrome_Bookmarks_Modal SHALL display link nodes with a favicon (using the Google favicon service) and the bookmark title.
5. WHEN a folder node is clicked to expand, THE Chrome_Bookmarks_Modal SHALL reveal its direct children inline without closing the modal.
6. THE Chrome_Bookmarks_Modal SHALL display an "Import Folder" button next to each folder node that contains at least one valid HTTP/HTTPS link (directly or in sub-folders).
7. THE Chrome_Bookmarks_Modal SHALL display an "Import Link" button next to each link node whose URL is a valid HTTP or HTTPS URL.
8. WHEN the Chrome_Bookmarks_Modal is closed, THE Importer SHALL reset the tree view state so it renders fresh on the next open.

### Requirement 3: Import a Single Link

**User Story:** As a user, I want to import a single Chrome bookmark link into PrivateLinkSaver, so that I can save individual pages without importing an entire folder.

#### Acceptance Criteria

1. WHEN the user clicks "Import Link" on a link node, THE Importer SHALL create a bookmark object with the Chrome bookmark's title and URL.
2. THE Importer SHALL assign the imported link to the currently selected folder in the main popup's folder dropdown (`folder-select-add`), or to the first available folder if none is selected.
3. THE Importer SHALL call `StorageUtils.saveBookmarks()` with the merged bookmark list to persist the new link.
4. IF the URL already exists in PrivateLinkSaver (detected by `Duplicate_Detector`), THEN THE Importer SHALL display a toast notification stating the link already exists and SHALL NOT create a duplicate entry.
5. WHEN the import succeeds, THE Importer SHALL display a success toast notification and refresh the bookmark view.

### Requirement 4: Import an Entire Folder

**User Story:** As a user, I want to import an entire Chrome bookmark folder into PrivateLinkSaver, so that I can migrate a group of related links at once.

#### Acceptance Criteria

1. WHEN the user clicks "Import Folder" on a folder node, THE Importer SHALL collect all link nodes within that folder and all of its descendant sub-folders recursively.
2. THE Importer SHALL filter the collected links to include only those with valid HTTP or HTTPS URLs.
3. IF a folder with the same name does not already exist in PrivateLinkSaver, THEN THE Importer SHALL create a new folder using the Chrome folder's exact name and a default color (`#3498db`), and persist it via `StorageUtils.saveFolders()`.
4. IF a folder with the same name already exists in PrivateLinkSaver, THEN THE Importer SHALL use the existing folder and SHALL NOT create a duplicate folder.
5. THE Importer SHALL assign all imported links to the folder identified in criteria 3 or 4.
6. THE Importer SHALL call `StorageUtils.saveBookmarks()` once with the full merged bookmark list after processing all links in the folder.
7. WHEN the import completes, THE Importer SHALL display a toast notification stating how many links were imported and how many were skipped as duplicates.
8. IF the folder contains zero valid HTTP/HTTPS links (after recursive traversal), THEN THE Importer SHALL display a toast notification stating the folder is empty and SHALL NOT create a new folder in PrivateLinkSaver.

### Requirement 5: Deduplication

**User Story:** As a user, I want duplicate links to be silently skipped during import, so that my bookmark list stays clean without manual cleanup.

#### Acceptance Criteria

1. BEFORE saving any imported bookmark, THE Importer SHALL compare the canonical form of the imported URL against the canonical URLs of all existing bookmarks in PrivateLinkSaver.
2. THE Importer SHALL use the same URL canonicalization logic already present in `StorageUtils` (strip tracking params, normalize trailing slashes, lowercase hostname).
3. IF an imported URL matches an existing canonical URL, THEN THE Importer SHALL skip that URL and increment a skipped-count counter.
4. THE Importer SHALL report the final skipped-count in the completion toast notification for folder imports.

### Requirement 6: State Refresh After Import

**User Story:** As a user, I want the bookmark list and folder list to update immediately after an import, so that I can see my newly imported items without reloading.

#### Acceptance Criteria

1. WHEN any import operation completes successfully, THE Importer SHALL reload `state.bookmarks` from `StorageUtils.getBookmarks()`.
2. WHEN any import operation completes successfully, THE Importer SHALL reload `state.folders` from `StorageUtils.getFolders()` and call `updateFolderDropdowns()`.
3. WHEN any import operation completes successfully, THE Importer SHALL call `refreshBookmarkView()` to re-render the bookmark list.
4. WHEN any import operation completes successfully, THE Importer SHALL call `updateStats()` to update the quick-stats counters.
