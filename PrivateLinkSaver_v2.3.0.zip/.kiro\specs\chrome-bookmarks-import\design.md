# Design Document: Chrome Bookmarks Import

## Overview

This feature adds a "Import from Chrome" flow to the PrivateLinkSaver extension. It lets users browse their native Chrome bookmark tree inside the popup and import individual links or entire folders into PrivateLinkSaver. The `bookmarks` optional permission is already declared in `manifest.json`; this feature wires it up for the first time.

The implementation is entirely client-side, touching three files:
- `popup.html` — new button in `data-actions`, new modal markup
- `styles/popup.css` — styles for the bookmark tree nodes
- `scripts/popup.js` — permission check, tree rendering, import logic

No new files or build steps are required.

## Architecture

```mermaid
sequenceDiagram
    participant User
    participant ImportBtn as Import from Chrome Button
    participant PermMgr as Permission Manager
    participant ChromeAPI as chrome.bookmarks API
    participant Modal as Chrome Bookmarks Modal
    participant Importer as Import Logic
    participant Storage as StorageUtils

    User->>ImportBtn: click
    ImportBtn->>PermMgr: checkAndRequestPermission()
    alt permission denied
        PermMgr-->>User: toast "permission required"
    else permission granted
        PermMgr->>ChromeAPI: chrome.bookmarks.getTree()
        ChromeAPI-->>Modal: bookmark tree data
        Modal-->>User: renders collapsible tree
        User->>Modal: click "Import Link" or "Import Folder"
        Modal->>Importer: importSingleLink(node) / importFolder(node)
        Importer->>Storage: getBookmarks(), getFolders()
        Importer->>Storage: saveBookmarks(), saveFolders()
        Importer-->>User: toast (success / skipped count)
        Importer->>Modal: refreshBookmarkView(), updateStats()
    end
```

## Components and Interfaces

### Permission Manager

A small helper function called once when the import button is clicked.

```js
async function checkAndRequestBookmarksPermission(): Promise<boolean>
```

- Calls `chrome.permissions.contains({ permissions: ['bookmarks'] })` first.
- If not granted, calls `chrome.permissions.request({ permissions: ['bookmarks'] })`.
- Returns `true` if permission is available, `false` otherwise.
- On `false`, calls `showToast(t('bookmarks_permission_required'), 'error')` and returns.

### Chrome Bookmarks Modal

A new `<div id="chrome-bookmarks-modal" class="modal">` added to `popup.html`, following the exact same `.modal / .modal-content / .modal-header / .modal-body` structure used by all existing modals.

The modal body contains a single `<div id="chrome-bookmarks-tree">` that is populated dynamically.

**Key functions:**

```js
async function openChromeBookmarksModal(): Promise<void>
// Requests tree, renders it, shows modal

function renderBookmarkTree(nodes: ChromeBookmarkNode[], container: HTMLElement): void
// Recursively renders nodes into container

function renderBookmarkNode(node: ChromeBookmarkNode): HTMLElement
// Returns a single DOM element for a folder or link node

function closeChromeBookmarksModal(): void
// Hides modal, clears tree container (reset state)
```

### Importer

Two import entry points, both living inside `popup.js`:

```js
async function importSingleLink(node: ChromeBookmarkNode): Promise<void>
// Imports one link node into the currently selected folder

async function importFolder(node: ChromeBookmarkNode): Promise<void>
// Recursively collects all valid links, creates/reuses folder, saves all
```

**Shared helper:**

```js
function collectValidLinks(node: ChromeBookmarkNode): ChromeBookmarkNode[]
// Recursively walks the tree, returns only nodes with valid HTTP/HTTPS URLs

function folderHasValidLinks(node: ChromeBookmarkNode): boolean
// Returns true if the folder (or any descendant) contains at least one valid link
```

### State Refresh

After any successful import, the following sequence runs:

```js
state.bookmarks = await StorageUtils.getBookmarks();
state.folders   = await StorageUtils.getFolders();
updateFolderDropdowns();
refreshBookmarkView();
await updateStats();
```

This reuses all existing functions — no new refresh mechanism is needed.

## Data Models

### ChromeBookmarkNode (from `chrome.bookmarks` API)

```ts
interface ChromeBookmarkNode {
  id: string;
  parentId?: string;
  title: string;
  url?: string;          // present only for link nodes; absent for folders
  children?: ChromeBookmarkNode[];
  dateAdded?: number;
}
```

A node is a **folder** when `url` is absent; a **link** when `url` is present.

### Bookmark object created on import

Reuses the existing shape normalized by `StorageUtils.normalizeBookmark()`:

```ts
{
  id: CryptoUtils.generateUUID(),
  title: node.title || node.url,
  url: StorageUtils.normalizeBookmarkUrl(node.url),   // canonical form
  folder: <selected folder name>,
  tags: [],
  favicon: null,
  date: new Date().toLocaleDateString('en', { year:'numeric', month:'short', day:'numeric' }),
  timestamp: Date.now(),
  visitCount: 0,
  lastVisited: null
}
```

### Folder object created on import

```ts
{
  id: CryptoUtils.generateUUID(),
  name: node.title,      // exact Chrome folder name
  color: '#3498db',      // default color per requirements
  isDefault: false,
  key: undefined
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Tree rendering completeness

*For any* Chrome bookmark tree (arbitrary depth and breadth), every node in the tree should appear as a rendered element in the modal container — no node should be silently dropped during rendering.

**Validates: Requirements 2.2**

### Property 2: Import button visibility matches URL validity

*For any* Chrome bookmark node, the "Import Link" button is present in its rendered element if and only if the node's URL is a valid HTTP or HTTPS URL; and the "Import Folder" button is present next to a folder node if and only if that folder contains at least one descendant with a valid HTTP or HTTPS URL.

**Validates: Requirements 2.6, 2.7**

### Property 3: Single link import preserves title and URL

*For any* Chrome link node with a valid HTTP/HTTPS URL, calling `importSingleLink` should produce exactly one new bookmark in storage whose title matches the node's title and whose URL is the canonical form of the node's URL.

**Validates: Requirements 3.1**

### Property 4: Deduplication — no duplicate bookmarks

*For any* set of existing bookmarks and any Chrome link node whose canonical URL already exists in that set, calling `importSingleLink` or `importFolder` should leave the total bookmark count unchanged.

**Validates: Requirements 3.4, 5.1, 5.2, 5.3**

### Property 5: Folder import collects all valid descendant links

*For any* Chrome folder node (including deeply nested sub-folders), `collectValidLinks` should return exactly the set of all descendant link nodes whose URLs are valid HTTP or HTTPS URLs — no more, no less.

**Validates: Requirements 4.1, 4.2**

### Property 6: Folder deduplication — no duplicate folders

*For any* existing folder list and any Chrome folder node whose name (case-insensitive) already exists in that list, importing that folder should leave the folder count unchanged and assign links to the existing folder.

**Validates: Requirements 4.4**

### Property 7: Import count accuracy

*For any* folder import, the numbers reported in the completion toast (imported count + skipped count) should equal the total number of valid HTTP/HTTPS links found in the folder tree.

**Validates: Requirements 4.7, 5.4**

## Error Handling

| Scenario | Handling |
|---|---|
| User denies `bookmarks` permission | Toast error, modal does not open |
| `chrome.bookmarks.getTree()` rejects | Toast error, modal does not open |
| Chrome folder has no valid HTTP/HTTPS links | Toast info "folder is empty", no folder created |
| Imported URL is a duplicate | Silently skip, increment skipped counter |
| `StorageUtils.saveBookmarks()` rejects | Toast error, state not refreshed |
| Bookmark node has no title | Fall back to the URL string as the title |
| URL fails `normalizeBookmarkUrl()` | Skip the node (treated as invalid) |

All async operations are wrapped in `try/catch`. Errors surface via `showToast(..., 'error')` using the existing toast system.

## Testing Strategy

This feature is a Chrome extension popup with UI interactions and Chrome API calls. The core logic worth unit-testing is the pure JavaScript: tree traversal, URL filtering, deduplication, and count reporting. UI rendering and Chrome API integration are tested with example-based tests using mocks.

**Property-based testing library:** [fast-check](https://github.com/dubzzz/fast-check) (runs in Node/Jest without a browser, suitable for pure logic tests).

**Unit / example tests** cover:
- Permission check branches (granted / denied)
- Modal open/close state reset
- Single link import with a known node
- Folder import with a known tree
- Empty folder edge case
- State refresh calls after import

**Property tests** (minimum 100 iterations each) cover Properties 1–7 above. Each test is tagged:

```
// Feature: chrome-bookmarks-import, Property N: <property text>
```

**Mocking strategy:**
- `chrome.bookmarks.getTree` — replaced with a fast-check generator that produces arbitrary `ChromeBookmarkNode` trees
- `StorageUtils.getBookmarks` / `saveBookmarks` / `getFolders` / `saveFolders` — replaced with in-memory stubs
- DOM — `jsdom` (via Jest) for rendering tests

Property tests run against the extracted pure functions (`collectValidLinks`, `folderHasValidLinks`, `renderBookmarkNode`) which have no Chrome API dependencies, keeping tests fast and deterministic.
