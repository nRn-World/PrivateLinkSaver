// PrivateLinkSaver - Background Service Worker

// Chrome loads vault.js here; Firefox lists it before this file in background.scripts.
if (typeof importScripts === 'function') importScripts('vault.js');

const TRACKING_PARAM_PREFIXES = ['utm_', 'ga_', 'mc_', 'pk_', 'sc_'];
const TRACKING_PARAM_EXACT = new Set([
    'fbclid', 'gclid', 'dclid', 'msclkid', 'yclid', '_hsenc', '_hsmi',
    'igshid', 'ref_src', 'campaign', 'si'
]);
const AUTO_LOGOUT_OPTIONS = new Set([5, 15, 30, 60]);
const DEFAULT_AUTO_LOGOUT_MINUTES = 15;
const AUTO_LOGOUT_ALARM = 'session-auto-logout-check';
const SESSION_ACTIVITY_THROTTLE_MS = 15000;

let lastSessionTouchAt = 0;

// Firefox for Android has no notifications, context menus, commands or omnibox: every use is optional.
function notify(options) {
    try {
        if (chrome.notifications && chrome.notifications.create) chrome.notifications.create(options);
    } catch (_error) { /* unsupported platform */ }
}

function setBadgeColor() {
    try {
        if (chrome.action && chrome.action.setBadgeBackgroundColor) chrome.action.setBadgeBackgroundColor({ color: '#0ea5e9' });
    } catch (_error) { /* unsupported platform */ }
}

function resolveDefaultLanguage() {
    const ui = String(chrome.i18n.getUILanguage() || 'en').toLowerCase();
    if (ui.startsWith('sv')) return 'sv';
    if (ui.startsWith('tr')) return 'tr';
    if (ui.startsWith('es')) return 'es';
    if (ui.startsWith('fr')) return 'fr';
    return 'en';
}

function normalizeAutoLogoutMinutes(value) {
    if (value === 'never' || value === 0 || value === '0') {
        return 0;
    }

    const parsed = Number(value);
    if (AUTO_LOGOUT_OPTIONS.has(parsed)) {
        return parsed;
    }

    return DEFAULT_AUTO_LOGOUT_MINUTES;
}

async function setupSessionAlarm() {
    const result = await chrome.storage.local.get('autoLogoutMinutes');
    const autoLogoutMinutes = normalizeAutoLogoutMinutes(result.autoLogoutMinutes);

    if (autoLogoutMinutes > 0) {
        chrome.alarms.create(AUTO_LOGOUT_ALARM, { periodInMinutes: 1 });
    } else {
        chrome.alarms.clear(AUTO_LOGOUT_ALARM);
    }
}

async function recordSessionActivity(force = false) {
    const result = await chrome.storage.local.get('isLoggedIn');
    if (!result.isLoggedIn) {
        return;
    }

    const now = Date.now();
    if (!force && now - lastSessionTouchAt < SESSION_ACTIVITY_THROTTLE_MS) {
        return;
    }

    lastSessionTouchAt = now;
    await chrome.storage.local.set({ sessionLastActiveAt: now });
}

async function handleAutoLogout(showNotification = false) {
    const result = await chrome.storage.local.get(['isLoggedIn', 'sessionLastActiveAt', 'autoLogoutMinutes']);
    const autoLogoutMinutes = normalizeAutoLogoutMinutes(result.autoLogoutMinutes);
    const lastActiveAt = Number(result.sessionLastActiveAt) || 0;

    if (!result.isLoggedIn || autoLogoutMinutes === 0 || !lastActiveAt) {
        return false;
    }

    if (Date.now() - lastActiveAt < autoLogoutMinutes * 60 * 1000) {
        return false;
    }

    lastSessionTouchAt = 0;
    await chrome.storage.local.set({
        isLoggedIn: false,
        autoLogoutNoticeMinutes: autoLogoutMinutes,
        autoLogoutNoticeAt: Date.now()
    });
    await Vault.lock();

    if (showNotification) {
        notify({
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'PrivateLinkSaver',
            message: `Signed out after ${autoLogoutMinutes} minutes of inactivity.`,
            priority: 1
        });
    }

    return true;
}

// Initialize extension on install
function syncSidePanelBehavior() {
    try {
        const sp = typeof chrome !== 'undefined' ? chrome['sidePanel'] : null;
        if (!sp || typeof sp['setPanelBehavior'] !== 'function') return;
        chrome.storage.local.get('preferSidePanel', (res) => {
            try {
                sp['setPanelBehavior']({ openPanelOnActionClick: Boolean(res && res.preferSidePanel) });
            } catch (_e) {}
        });
    } catch (_e) {}
}

syncSidePanelBehavior();

chrome.runtime.onInstalled.addListener((details) => {
    syncSidePanelBehavior();
    // Open feedback page when the user uninstalls the extension
    try {
        if (chrome.runtime && chrome.runtime.setUninstallURL) {
            chrome.runtime.setUninstallURL('https://nrnworld.one/PrivateLinkSaver/uninstall.html');
        }
    } catch (_e) { /* unsupported platform */ }

    // Set default badge color
    setBadgeColor();

    // Set default auto-logout to 15 minutes if not already set
    chrome.storage.local.get('autoLogoutMinutes', (result) => {
        if (result.autoLogoutMinutes === undefined) {
            chrome.storage.local.set({ autoLogoutMinutes: 15 });
        }
    });

    // Default language (English) and UI style (Soft Pastel for new installs, Classic + banner for updates)
    chrome.storage.local.get(['language', 'firstTime', 'showPinHint', 'uiStyle', 'showStyleBanner'], (result) => {
        const updates = {};

        if (result.language === undefined) {
            updates.language = 'en';
        }

        if (details.reason === 'install') {
            if (result.firstTime === undefined) {
                updates.firstTime = true;
            }
            if (result.showPinHint === undefined) {
                updates.showPinHint = true;
            }
            if (result.uiStyle === undefined) {
                updates.uiStyle = 'pastel';
            }
            updates.showStyleBanner = false;
            try {
                if (chrome.tabs && chrome.tabs.create) {
                    chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') });
                }
            } catch (_e) { /* unsupported platform */ }
        } else if (details.reason === 'update') {
            if (result.uiStyle === undefined) {
                updates.uiStyle = 'classic';
            }
            updates.showStyleBanner = true;
        }

        if (Object.keys(updates).length > 0) {
            chrome.storage.local.set(updates);
        }
    });
    
    // Create context menus (not available on Firefox for Android)
    if (chrome.contextMenus) chrome.contextMenus.removeAll(() => {
        chrome.contextMenus.create({
            id: 'save-link',
            title: chrome.i18n.getMessage('contextSaveLink') || 'Save link to PrivateLinkSaver',
            contexts: ['link']
        });
        
        chrome.contextMenus.create({
            id: 'save-page',
            title: chrome.i18n.getMessage('contextSavePage') || 'Save page to PrivateLinkSaver',
            contexts: ['page']
        });

        chrome.contextMenus.create({
            id: 'save-all-tabs',
            title: chrome.i18n.getMessage('contextSaveAllTabs') || 'Save all open tabs to PrivateLinkSaver',
            contexts: ['page']
        });
    });
    
    // Set up auto-backup alarm if enabled
    setupAutoBackup();
    setupSessionAlarm();
    handleAutoLogout();
    
    // Update badge with current bookmark count
    updateBadge();
});

chrome.runtime.onStartup.addListener(() => {
    setupAutoBackup();
    setupSessionAlarm();
    handleAutoLogout();
    updateBadge();
});

// Set up auto-backup alarm
async function setupAutoBackup() {
    const result = await chrome.storage.local.get('autoBackup');
    if (result.autoBackup) {
        chrome.alarms.create('auto-backup', {
            periodInMinutes: 24 * 60 // Daily
        });
    } else {
        chrome.alarms.clear('auto-backup');
    }
}

// Handle alarms
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'auto-backup') {
        createAutoBackup();
    } else if (alarm.name === AUTO_LOGOUT_ALARM) {
        handleAutoLogout(true);
    }
});

// Create automatic backup
async function createAutoBackup() {
    try {
        const result = await Vault.localGet(['bookmarks', 'folders', 'tags']);
        const backup = {
            id: generateUUID(),
            date: new Date().toISOString(),
            auto: true,
            data: {
                 version: '2.5.0',
                 exportDate: new Date().toISOString(),
                bookmarks: result.bookmarks || [],
                folders: result.folders || [],
                tags: result.tags || []
            }
        };
        
        const backupsResult = await Vault.localGet('backups');
        const backups = backupsResult.backups || [];
        backups.push(backup);
        
        // Keep only last 10 backups
        if (backups.length > 10) {
            backups.shift();
        }
        
        try {
            await Vault.localSet({ backups });
        } catch (error) {
            console.error('Auto-backup storage error:', error);
            notify({
                type: 'basic',
                iconUrl: 'icons/icon128.png',
                title: 'PrivateLinkSaver',
                message: 'Storage full. Auto-backup failed.',
                priority: 2
            });
        }
    } catch (error) {
        console.error('Auto-backup failed:', error);
    }
}

// Handle context menu clicks
if (chrome.contextMenus && chrome.contextMenus.onClicked) chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === 'save-link') {
        let linkTitle = info.selectionText;
        if (!linkTitle) {
            try { linkTitle = new URL(info.linkUrl).hostname.replace(/^www\./, ''); } catch (_e) { linkTitle = 'Saved Link'; }
        }
        saveBookmark(info.linkUrl, linkTitle, tab);
    } else if (info.menuItemId === 'save-page') {
        saveBookmark(tab.url, tab.title, tab);
    } else if (info.menuItemId === 'save-all-tabs') {
        saveAllTabs().then((r) => notify({ type: 'basic', iconUrl: 'icons/icon128.png', title: 'PrivateLinkSaver',
            message: r.success ? ('Saved ' + r.added + ' tabs (' + r.skipped + ' skipped)') : r.error, priority: 1 }));
    }
});

// Handle keyboard shortcuts
if (chrome.commands && chrome.commands.onCommand) chrome.commands.onCommand.addListener((command) => {
    if (command === 'save-current-page') {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                saveBookmark(tabs[0].url, tabs[0].title, tabs[0]);
            }
        });
    } else if (command === 'save-all-tabs') {
        saveAllTabs().then((r) => notify({ type: 'basic', iconUrl: 'icons/icon128.png', title: 'PrivateLinkSaver',
            message: r.success ? ('Saved ' + r.added + ' tabs (' + r.skipped + ' skipped)') : r.error, priority: 1 }));
    } else if (command === 'quick-search') {
        // Try to focus search if popup is open
        Promise.resolve(chrome.runtime.sendMessage({ action: 'focusSearch' })).catch(() => {});
    }
});

// Handle omnibox input
if (chrome.omnibox) chrome.omnibox.onInputChanged.addListener((text, suggest) => {
    Promise.all([
        chrome.storage.local.get('isLoggedIn'),
        Vault.localGet('bookmarks')
    ]).then(([login, result]) => {
        if (!login.isLoggedIn || !result.bookmarks) {
            return;
        }
        
        const matches = result.bookmarks
            .filter(b => 
                b.title.toLowerCase().includes(text.toLowerCase()) ||
                b.url.toLowerCase().includes(text.toLowerCase())
            )
            .slice(0, 5)
            .map(b => ({
                content: b.url,
                description: `<match>${escapeXml(b.title)}</match> - <url>${escapeXml(b.url)}</url>`
            }));
        
        suggest(matches);
    }).catch(() => { /* vault locked: no suggestions */ });
});

if (chrome.omnibox) chrome.omnibox.onInputEntered.addListener((url) => {
    chrome.tabs.create({ url });
});

// Escape XML for omnibox
function escapeXml(str) {
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

// Save every open http(s) tab in the current window (skips duplicates)
async function saveAllTabs(folderName) {
    const login = await chrome.storage.local.get(['isLoggedIn', 'passwordHash']);
    if (!login.isLoggedIn || !login.passwordHash) return { success: false, error: 'Please log in first' };
    let data;
    try { data = await Vault.localGet(['bookmarks', 'language', 'folders']); }
    catch (_e) { return { success: false, error: 'Please log in first' }; }
    const bookmarks = data.bookmarks || [];
    const folders = data.folders || [];
    const lang = data.language || 'en';
    const folder = folderName || (folders.length > 0 ? folders[0].name : 'General');
    const known = new Set(bookmarks.map((b) => canonicalUrl(b.url)));
    const tabs = await chrome.tabs.query({ currentWindow: true });
    let added = 0, skipped = 0;
    for (const tab of tabs) {
        const url = normalizeBookmarkUrl(tab.url);
        const canon = url && canonicalUrl(url);
        if (!url || known.has(canon)) { skipped++; continue; }
        known.add(canon);
        const title = String(tab.title || url).trim();
        let favicon = tab.favIconUrl || null;
        if (!favicon) { try { favicon = 'https://www.google.com/s2/favicons?domain=' + new URL(url).hostname + '&sz=64'; } catch (_e) {} }
        bookmarks.push({
            id: generateUUID(), title, url, folder,
            tags: inferSmartTags(url, title), favicon,
            date: new Date().toLocaleDateString(lang, { year: 'numeric', month: 'short', day: 'numeric' }),
            timestamp: Date.now(), visitCount: 0, lastVisited: null
        });
        added++;
    }
    if (added > 0) {
        try { await Vault.localSet({ bookmarks }); } catch (_e) { return { success: false, error: 'Save failed' }; }
        updateBadge();
    }
    return { success: true, added, skipped };
}

// Save a bookmark
async function saveBookmark(url, title, tab) {
    const sessionExpired = await handleAutoLogout();
    if (sessionExpired) {
        notify({
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'PrivateLinkSaver',
            message: 'Please unlock PrivateLinkSaver again to save bookmarks.',
            priority: 1
        });
        return;
    }

    const normalizedUrl = normalizeBookmarkUrl(url);
    if (!normalizedUrl) {
        notify({
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'PrivateLinkSaver',
            message: 'Unsupported link type. Only HTTP/HTTPS URLs can be saved.',
            priority: 1
        });
        return;
    }

    // Check if user is logged in
    const result = await chrome.storage.local.get(['isLoggedIn', 'passwordHash']);
    
    if (!result.isLoggedIn || !result.passwordHash) {
        notify({
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'PrivateLinkSaver',
            message: chrome.i18n.getMessage('notificationLoginRequired') || 'Please log in to save bookmarks',
            priority: 2
        });
        return;
    }
    
    // Get current bookmarks and preferences
    let data;
    try {
        data = await Vault.localGet(['bookmarks', 'language', 'folders']);
    } catch (error) {
        // Encrypted vault without its key (e.g. browser restarted): ask for a fresh login.
        notify({
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'PrivateLinkSaver',
            message: chrome.i18n.getMessage('notificationLoginRequired') || 'Please log in to save bookmarks',
            priority: 2
        });
        return;
    }
    const bookmarks = data.bookmarks || [];
    const currentLang = data.language || 'en';
    const folders = data.folders || [];
    const safeTitle = String(title || normalizedUrl || 'Untitled').trim();
    const normalizedCanonical = canonicalUrl(normalizedUrl);
    
    // Check if bookmark already exists
    const exists = bookmarks.some((bookmark) => canonicalUrl(bookmark.url) === normalizedCanonical);
    if (exists) {
        notify({
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'PrivateLinkSaver',
            message: chrome.i18n.getMessage('notificationExists') || 'This page is already saved!',
            priority: 1
        });
        return;
    }
    
    // Get favicon (tab icon when saving the current page, else Google's favicon service)
    let favicon = tab && tab.favIconUrl ? tab.favIconUrl : null;
    if (!favicon) {
        try {
            const domain = new URL(normalizedUrl).hostname;
            if (domain && domain.includes('.') && domain !== 'localhost' && !/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(domain)) {
                favicon = `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
            }
        } catch (e) {
            // Invalid URL, skip favicon
        }
    }

    // Get default folder
    const defaultFolder = folders.length > 0 ? folders[0].name : 'General';
    
    // Create new bookmark
    const newBookmark = {
        id: generateUUID(),
        title: safeTitle,
        url: normalizedUrl,
        folder: defaultFolder,
        tags: inferSmartTags(normalizedUrl, safeTitle),
        favicon: favicon,
        date: new Date().toLocaleDateString(currentLang, {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        }),
        timestamp: Date.now(),
        visitCount: 0,
        lastVisited: null
    };
    
    // Save bookmark
    bookmarks.push(newBookmark);
    try {
        await Vault.localSet({ bookmarks });
    } catch (error) {
        console.error('Failed to save bookmark:', error);
        notify({
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'PrivateLinkSaver',
            message: chrome.i18n.getMessage('storage_full') || 'Storage is full. Please free up some space.',
            priority: 2
        });
        return;
    }

    // Show success notification
    const truncatedTitle = safeTitle.length > 50 ? safeTitle.substring(0, 50) + '...' : safeTitle;
    notify({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'PrivateLinkSaver Pro',
        message: `Saved: ${truncatedTitle}`,
        priority: 1
    });
    
    // Update badge
    updateBadge();
    recordSessionActivity(true);
}

// Update badge with bookmark count
async function updateBadge() {
    // Never show a badge count - keep icon clean
    try { chrome.action.setBadgeText({ text: '' }); } catch (_error) { /* unsupported platform */ }
}

// Listen for storage changes to update badge
chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
        if (changes.bookmarks) {
            updateBadge();
        }

        if (changes.autoLogoutMinutes) {
            setupSessionAlarm();
            handleAutoLogout();
        }
    }
});

// Handle messages from popup or other parts of the extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'updateBadge') {
        updateBadge().then(() => sendResponse({ success: true }));
        return true;
    } else if (request.action === 'updateSessionSettings') {
        setupSessionAlarm()
            .then(() => handleAutoLogout())
            .then(() => sendResponse({ success: true }));
        return true;
    } else if (request.action === 'saveAllTabs') {
        saveAllTabs(request.folder).then(sendResponse).catch((e) => sendResponse({ success: false, error: String(e) }));
        return true;
    } else if (request.action === 'saveCurrentPage') {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                saveBookmark(tabs[0].url, tabs[0].title, tabs[0]);
                sendResponse({ success: true });
            } else {
                sendResponse({ success: false, error: 'No active tab' });
            }
        });
        return true;
    } else if (request.action === 'trackVisit') {
        Vault.localGet('bookmarks').then((data) => {
            const list = data.bookmarks || [];
            const bookmark = list.find((b) => b.id === request.id);
            if (!bookmark) return;
            bookmark.visitCount = (Number(bookmark.visitCount) || 0) + 1;
            bookmark.lastVisited = Date.now();
            return Vault.localSet({ bookmarks: list });
        }).then(() => sendResponse({ success: true }), () => sendResponse({ success: false }));
        return true;
    } else if (request.action === 'createBackup') {
        createAutoBackup().then(() => sendResponse({ success: true }));
        return true;
    } else if (request.action === 'setupAutoBackup') {
        setupAutoBackup().then(() => sendResponse({ success: true }));
        return true;
    }
    
    return false;
});

// Generate UUID (cryptographically secure)
function generateUUID() {
    return crypto.randomUUID();
}

function isSafeHttpUrl(url) {
    try {
        const parsed = new URL(url);
        return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch (_error) {
        return false;
    }
}

function normalizeBookmarkUrl(url) {
    try {
        const parsed = new URL(String(url || '').trim());
        if (!isSafeHttpUrl(parsed.href)) {
            return null;
        }

        Array.from(parsed.searchParams.keys()).forEach((paramName) => {
            const key = paramName.toLowerCase();
            if (TRACKING_PARAM_EXACT.has(key) || TRACKING_PARAM_PREFIXES.some((prefix) => key.startsWith(prefix))) {
                parsed.searchParams.delete(paramName);
            }
        });

        // Keep "#/route" and "#!route" (hash-routed apps); drop plain anchors.
        if (!/^#[\/!]/.test(parsed.hash)) parsed.hash = '';
        parsed.hostname = parsed.hostname.toLowerCase();

        if (parsed.pathname !== '/' && parsed.pathname.endsWith('/')) {
            parsed.pathname = parsed.pathname.replace(/\/+$/, '');
        }

        if ((parsed.protocol === 'https:' && parsed.port === '443') || (parsed.protocol === 'http:' && parsed.port === '80')) {
            parsed.port = '';
        }

        return parsed.href;
    } catch (_error) {
        return null;
    }
}

function canonicalUrl(url) {
    return normalizeBookmarkUrl(url);
}

function inferSmartTags(url, title) {
    const tags = [];
    try {
        const hostname = new URL(url).hostname.replace(/^www\./, '').toLowerCase();
        const domainTag = hostname.split('.')[0];
        if (domainTag && domainTag.length > 2) {
            tags.push(domainTag);
        }
    } catch (_error) {
        // ignore invalid URL
    }

    const stopWords = new Set([
        'the', 'and', 'for', 'with', 'this', 'that', 'from', 'your', 'you',
        'guide', 'tips', 'what', 'when', 'where', 'about', 'www', 'com'
    ]);

    String(title || '')
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, ' ')
        .split(/\s+/)
        .filter((word) => word.length >= 4 && !stopWords.has(word))
        .slice(0, 5)
        .forEach((word) => {
            if (!tags.includes(word)) {
                tags.push(word);
            }
        });

    return tags.slice(0, 4);
}
